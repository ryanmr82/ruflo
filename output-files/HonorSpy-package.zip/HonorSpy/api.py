#!/usr/bin/env python3
"""
HonorSpy API Server
Receives player data from multiple contributors and merges it into a unified dashboard.
Runs on port 5002, proxied through nginx at /honorspy/api/
"""

import os
import json
import time
import math
import logging
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS

# Configuration
DATA_DIR = '/home/opc/HonorSpy/data'
CONTRIBUTORS_DIR = '/home/opc/HonorSpy/contributors'
LOGS_DIR = '/home/opc/HonorSpy/logs'
SNAPSHOTS_DIR = '/home/opc/HonorSpy/snapshots'
OUTPUT_FILE = '/var/www/html/honorspy/index.html'
AWARDS_OUTPUT_FILE = '/var/www/html/honorspy/awards.html'
MERGED_DATA_FILE = os.path.join(DATA_DIR, 'merged_players.json')

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(LOGS_DIR, 'api.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests from contributors


def load_merged_data():
    """Load the current merged player data."""
    if os.path.exists(MERGED_DATA_FILE):
        try:
            with open(MERGED_DATA_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading merged data: {e}")
    return {'players': {}, 'last_updated': 0, 'contributors': {}}


def save_merged_data(data):
    """Save the merged player data."""
    try:
        with open(MERGED_DATA_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving merged data: {e}")


def merge_player_data(existing_data, new_players, contributor_name):
    """
    Merge new player data into existing data.
    For each player, keep the record with the most recent last_checked timestamp.
    """
    merged = existing_data.get('players', {})

    for player in new_players:
        name = player.get('name')
        if not name:
            continue

        new_last_checked = player.get('last_checked', 0)

        # If player doesn't exist or new data is equally recent or more recent, update
        if name not in merged or new_last_checked >= merged[name].get('last_checked', 0):
            merged[name] = player
            merged[name]['contributor'] = contributor_name

    existing_data['players'] = merged
    existing_data['last_updated'] = int(time.time())

    # Track contributor stats
    if 'contributors' not in existing_data:
        existing_data['contributors'] = {}
    existing_data['contributors'][contributor_name] = {
        'last_upload': int(time.time()),
        'players_submitted': len(new_players)
    }

    return existing_data




# Bracket calculation for projections (Python version of JS function)
def calculate_bracket(standing, pool_size):
    """Calculate bracket based on standing and pool size."""
    brackets = [
        (0.003, 14), (0.006, 13), (0.012, 12), (0.025, 11), (0.05, 10),
        (0.10, 9), (0.15, 8), (0.20, 7), (0.35, 6), (0.50, 5),
        (0.65, 4), (0.80, 3), (0.95, 2), (1.0, 1)
    ]
    percentile = standing / pool_size
    for threshold, bracket in brackets:
        if percentile <= threshold:
            return bracket
    return 1

def calculate_rp_gain(standing, bracket, honor, pool_size):
    """Calculate RP gain based on bracket and honor."""
    if honor < 15:
        return 0
    
    rp_values = {
        14: 13000, 13: 12000, 12: 11000, 11: 10000, 10: 9000,
        9: 8000, 8: 7000, 7: 6000, 6: 5000, 5: 4000,
        4: 3500, 3: 3000, 2: 2500, 1: 2000
    }
    return rp_values.get(bracket, 0)

def calculate_projections_for_player(player_data, standing, pool_size):
    """Calculate all projections for a player."""
    rp = player_data.get('RP', 0)
    honor = player_data.get('thisWeekHonor', 0)
    
    bracket = calculate_bracket(standing, pool_size)
    decay = int(rp * 0.20)
    gain = calculate_rp_gain(standing, bracket, honor, pool_size)
    net = gain - decay
    projected_rp = rp + net
    
    # Calculate projected rank from projected RP
    rank_thresholds = [
        (60000, 14), (55000, 13), (50000, 12), (45000, 11), (40000, 10),
        (35000, 9), (30000, 8), (25000, 7), (20000, 6), (15000, 5),
        (10000, 4), (5000, 3), (2000, 2), (0, 1)
    ]
    projected_rank = 0
    for threshold, rank in rank_thresholds:
        if projected_rp >= threshold:
            projected_rank = rank
            break
    
    return {
        'standing': standing,
        'bracket': bracket,
        'decay': decay,
        'gain': gain,
        'net': net,
        'projected_rp': projected_rp,
        'projected_rank': projected_rank
    }


def take_snapshot(label='pre_reset'):
    """Take a snapshot of current player data for later comparison."""
    merged_data = load_merged_data()
    players = merged_data.get('players', {})

    if not players:
        return None, "No player data to snapshot"

    timestamp = int(time.time())
    date_str = datetime.now().strftime('%Y-%m-%d_%H-%M')

    snapshot = {
        'timestamp': timestamp,
        'date': date_str,
        'label': label,
        'player_count': len(players),
        'players': {}
    }

    # Sort players by honor to determine standings
    sorted_players = sorted(players.items(), key=lambda x: x[1].get('thisWeekHonor', 0), reverse=True)
    pool_size = len(sorted_players)

    # Store RP, rank, progress, honor, and PROJECTIONS for each player
    for standing, (name, data) in enumerate(sorted_players, 1):
        player_snapshot = {
            'RP': data.get('RP', 0),
            'rank': data.get('rank', 0),
            'progress': data.get('progress', 0),
            'thisWeekHonor': data.get('thisWeekHonor', 0),
            'lastWeekHonor': data.get('lastWeekHonor', 0),
            'class': data.get('class', 'Unknown')
        }
        
        # For pre_reset snapshots, also store projections
        if label == 'pre_reset' or label.startswith('pre_'):
            projections = calculate_projections_for_player(data, standing, pool_size)
            player_snapshot.update(projections)
        
        snapshot['players'][name] = player_snapshot

    # Save snapshot
    filename = f"{label}_{date_str}.json"
    filepath = os.path.join(SNAPSHOTS_DIR, filename)

    try:
        with open(filepath, 'w') as f:
            json.dump(snapshot, f, indent=2)
        logger.info(f"Snapshot saved: {filename} with {len(players)} players")
        return snapshot, None
    except Exception as e:
        logger.error(f"Error saving snapshot: {e}")
        return None, str(e)


def get_snapshots():
    """List all available snapshots."""
    snapshots = []
    try:
        for filename in os.listdir(SNAPSHOTS_DIR):
            if filename.endswith('.json'):
                filepath = os.path.join(SNAPSHOTS_DIR, filename)
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    snapshots.append({
                        'filename': filename,
                        'label': data.get('label', 'unknown'),
                        'date': data.get('date', ''),
                        'timestamp': data.get('timestamp', 0),
                        'player_count': data.get('player_count', 0)
                    })
        snapshots.sort(key=lambda x: x['timestamp'], reverse=True)
    except Exception as e:
        logger.error(f"Error listing snapshots: {e}")
    return snapshots


def get_latest_snapshot(label='pre_reset'):
    """Get the most recent snapshot with the given label."""
    snapshots = get_snapshots()
    for snap in snapshots:
        if snap['label'] == label:
            filepath = os.path.join(SNAPSHOTS_DIR, snap['filename'])
            try:
                with open(filepath, 'r') as f:
                    return json.load(f)
            except:
                pass
    return None


def get_snapshot_by_filename(filename):
    """Load a specific snapshot by filename."""
    filepath = os.path.join(SNAPSHOTS_DIR, filename)
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except:
            pass
    return None


def get_week_pairs():
    """Find matching pre-reset and post-reset snapshot pairs for each week."""
    snapshots = get_snapshots()

    # Group snapshots by week (using the date part)
    pre_resets = {}
    post_resets = {}

    for snap in snapshots:
        # Extract date from filename (format: label_YYYY-MM-DD_HH-MM.json)
        date_part = snap['date'].split('_')[0]  # Get YYYY-MM-DD

        if snap['label'] == 'pre_reset':
            # Keep the latest pre_reset for each date
            if date_part not in pre_resets or snap['timestamp'] > pre_resets[date_part]['timestamp']:
                pre_resets[date_part] = snap
        elif snap['label'].startswith('post_reset'):
            # Keep any post_reset for each date
            if date_part not in post_resets or snap['timestamp'] > post_resets[date_part]['timestamp']:
                post_resets[date_part] = snap

    # Create pairs
    pairs = []
    for date, pre_snap in pre_resets.items():
        post_snap = post_resets.get(date)
        pairs.append({
            'week_date': date,
            'pre_reset': pre_snap,
            'post_reset': post_snap  # May be None if no post-reset snapshot yet
        })

    # Sort by date descending (most recent first)
    pairs.sort(key=lambda x: x['week_date'], reverse=True)
    return pairs


def calculate_awards_from_snapshots(pre_filename, post_filename):
    """Calculate RP awards by comparing two specific snapshots."""
    pre_reset = get_snapshot_by_filename(pre_filename)
    if not pre_reset:
        return None, f"Pre-reset snapshot not found: {pre_filename}"

    post_reset = get_snapshot_by_filename(post_filename)
    if not post_reset:
        return None, f"Post-reset snapshot not found: {post_filename}"

    pre_reset_players = pre_reset.get('players', {})
    post_reset_players = post_reset.get('players', {})

    awards = []

    for name, pre in pre_reset_players.items():
        if name in post_reset_players:
            post = post_reset_players[name]

            pre_rp = pre.get('RP', 0)
            post_rp = post.get('RP', 0)

            # Award = Post-reset RP - (Pre-reset RP * 0.80)
            decay = math.floor(pre_rp * 0.20)
            calculated_award = post_rp - (pre_rp - decay)

            awards.append({
                'name': name,
                'class': pre.get('class', 'Unknown'),
                'pre_reset_honor': pre.get('thisWeekHonor', 0),
                'last_week_honor': post.get('lastWeekHonor', pre.get('thisWeekHonor', 0)),
                'pre_reset_rp': pre_rp,
                'pre_reset_rank': pre.get('rank', 0),
                'pre_reset_progress': pre.get('progress', 0),
                'post_reset_rp': post_rp,
                'post_reset_rank': post.get('rank', 0),
                'post_reset_progress': post.get('progress', 0),
                'decay': decay,
                'award': calculated_award,
                'net_gain': post_rp - pre_rp,
                'current_honor': post.get('thisWeekHonor', 0)
            })

    # Sort by pre-reset honor (standing at reset)
    awards.sort(key=lambda x: x['pre_reset_honor'], reverse=True)

    # Add standing numbers
    for i, a in enumerate(awards):
        a['standing'] = i + 1

    return {
        'pre_snapshot': pre_filename,
        'post_snapshot': post_filename,
        'pre_snapshot_date': pre_reset.get('date', 'Unknown'),
        'post_snapshot_date': post_reset.get('date', 'Unknown'),
        'calculated_at': int(time.time()),
        'player_count': len(awards),
        'awards': awards
    }, None


def calculate_awards():
    """Calculate RP awards by comparing current data to pre-reset snapshot."""
    pre_reset = get_latest_snapshot('pre_reset')
    if not pre_reset:
        return None, "No pre-reset snapshot found"

    current_data = load_merged_data()
    current_players = current_data.get('players', {})
    pre_reset_players = pre_reset.get('players', {})

    awards = []

    for name, current in current_players.items():
        if name in pre_reset_players:
            pre = pre_reset_players[name]

            pre_rp = pre.get('RP', 0)
            post_rp = current.get('RP', 0)

            # Award = Post-reset RP - (Pre-reset RP * 0.80)
            # Because: Post = Pre * 0.80 + Award
            decay = math.floor(pre_rp * 0.20)
            calculated_award = post_rp - (pre_rp - decay)

            awards.append({
                'name': name,
                'class': current.get('class', 'Unknown'),
                'pre_reset_honor': pre.get('thisWeekHonor', 0),
                'pre_reset_rp': pre_rp,
                'pre_reset_rank': pre.get('rank', 0),
                'pre_reset_progress': pre.get('progress', 0),
                'post_reset_rp': post_rp,
                'post_reset_rank': current.get('rank', 0),
                'post_reset_progress': current.get('progress', 0),
                'decay': decay,
                'award': calculated_award,
                'net_gain': post_rp - pre_rp,
                'current_honor': current.get('thisWeekHonor', 0)
            })

    # Sort by pre-reset honor (standing at reset)
    awards.sort(key=lambda x: x['pre_reset_honor'], reverse=True)

    # Add standing numbers
    for i, a in enumerate(awards):
        a['standing'] = i + 1

    return {
        'snapshot_date': pre_reset.get('date', 'Unknown'),
        'snapshot_timestamp': pre_reset.get('timestamp', 0),
        'calculated_at': int(time.time()),
        'player_count': len(awards),
        'awards': awards
    }, None


def generate_awards_html(awards_data):
    """Generate the awards comparison HTML page."""
    if not awards_data:
        return "<html><body><h1>No awards data available</h1></body></html>"

    awards = awards_data.get('awards', [])
    pre_date = awards_data.get('pre_snapshot_date', awards_data.get('snapshot_date', 'Unknown'))
    post_date = awards_data.get('post_snapshot_date', 'Current')
    calc_time = datetime.fromtimestamp(awards_data.get('calculated_at', 0)).strftime('%Y-%m-%d %H:%M:%S')
    player_count = awards_data.get('player_count', len(awards))

    # Get available week pairs for the dropdown
    week_pairs = get_week_pairs()
    week_pairs_json = json.dumps(week_pairs)

    # Convert to JSON for JavaScript
    awards_json = json.dumps(awards)

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Reset Awards - HonorSpy</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #eee;
            padding: 10px 15px;
            font-size: 14px;
        }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }}
        h1 {{ color: #ffd700; font-size: 1.5em; }}
        .subtitle {{ color: #888; font-size: 0.85em; }}
        .week-indicator {{
            background: rgba(255,215,0,0.2);
            color: #ffd700;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: bold;
            margin-left: 10px;
        }}
        .back-link {{ color: #4fc3f7; text-decoration: none; }}
        .back-link:hover {{ text-decoration: underline; }}
        .controls {{
            background: rgba(255,255,255,0.05);
            border-radius: 6px;
            padding: 8px 12px;
            margin-bottom: 10px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }}
        .control-group {{
            display: flex;
            align-items: center;
            gap: 5px;
        }}
        .control-group label {{
            color: #ffd700;
            font-weight: bold;
            font-size: 0.85em;
        }}
        .control-group input, .control-group select {{
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,215,0,0.5);
            border-radius: 4px;
            padding: 4px 8px;
            color: #fff;
            font-size: 0.9em;
        }}
        .control-group select {{
            cursor: pointer;
        }}
        .control-group select option {{
            background: #1a1a2e;
            color: #fff;
        }}
        .control-group input[type="text"] {{ width: 150px; }}
        .control-group input[type="number"] {{ width: 60px; }}
        .control-group input:focus, .control-group select:focus {{ outline: none; border-color: #ffd700; }}
        .stats-bar {{
            display: flex;
            gap: 20px;
            margin-bottom: 10px;
            font-size: 0.9em;
        }}
        .stat-item {{
            color: #aaa;
        }}
        .stat-item strong {{
            color: #ffd700;
        }}
        .no-data-warning {{
            background: rgba(255,107,107,0.2);
            border: 1px solid #ff6b6b;
            border-radius: 6px;
            padding: 10px 15px;
            margin-bottom: 10px;
            color: #ff6b6b;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            background: rgba(255,255,255,0.05);
            border-radius: 6px;
            overflow: hidden;
            font-size: 0.95em;
        }}
        th {{
            background: rgba(255,215,0,0.2);
            color: #ffd700;
            padding: 8px;
            text-align: left;
            font-weight: bold;
            font-size: 0.85em;
        }}
        td {{
            padding: 6px 8px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }}
        tr:hover {{ background: rgba(255,215,0,0.1); }}
        .rank-col {{ font-weight: bold; color: #ffd700; }}
        .award-col {{ color: #51cf66; font-weight: bold; }}
        .gain-col {{ color: #51cf66; }}
        .loss-col {{ color: #ff6b6b; }}
        .class-WARRIOR {{ color: #C79C6E; }}
        .class-PALADIN {{ color: #F58CBA; }}
        .class-HUNTER {{ color: #ABD473; }}
        .class-ROGUE {{ color: #FFF569; }}
        .class-PRIEST {{ color: #FFFFFF; }}
        .class-SHAMAN {{ color: #0070DE; }}
        .class-MAGE {{ color: #69CCF0; }}
        .class-WARLOCK {{ color: #9482C9; }}
        .class-DRUID {{ color: #FF7D0A; }}
        .loading-overlay {{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }}
        .loading-overlay.hidden {{
            display: none;
        }}
        .loading-spinner {{
            color: #ffd700;
            font-size: 1.2em;
        }}
    
        /* Sortable column headers */
        th.sortable {{
            cursor: pointer;
            user-select: none;
            position: relative;
            padding-right: 18px !important;
        }}
        th.sortable:hover {{
            background: #333;
        }}
        th.sortable::after {{
            content: "";
            position: absolute;
            right: 4px;
            opacity: 0.3;
            font-size: 0.75em;
        }}
        th.sortable.sort-asc::after {{
            content: " ^";
            opacity: 1;
            color: #4dabf7;
        }}
        th.sortable.sort-desc::after {{
            content: " v";
            opacity: 1;
            color: #4dabf7;
        }}
    </style>
</head>
<body>
    <div id="loadingOverlay" class="loading-overlay hidden">
        <div class="loading-spinner">Loading awards data...</div>
    </div>
    <div class="container">
        <div class="header">
            <div>
                <h1>Weekly Reset Awards</h1>
                <span class="week-indicator" id="weekIndicator">{player_count} players</span>
            </div>
            <a href="" class="back-link" id="backLink">&larr; Back to Dashboard</a>
        </div>
        <div class="stats-bar" id="statsBar">
            <div class="stat-item">Pre-reset: <strong id="preDate">{pre_date}</strong></div>
            <div class="stat-item">Post-reset: <strong id="postDate">{post_date}</strong></div>
            <div class="stat-item">Calculated: <strong>{calc_time}</strong></div>
        </div>
        <div id="noDataWarning" class="no-data-warning" style="display: none;">
            No post-reset snapshot available for this week yet. Awards cannot be calculated.
        </div>
        <div class="controls">
            <div class="control-group">
                <label>Week:</label>
                <select id="weekSelector" onchange="changeWeek()">
                </select>
            </div>
            <div class="control-group">
                <label>Search:</label>
                <input type="text" id="playerSearch" placeholder="Player name..." oninput="updateTable()">
            </div>
            <div class="control-group">
                <label>Show:</label>
                <input type="number" id="displayCount" value="50" min="1" max="2000" onchange="updateTable()">
            </div>
            <div class="control-group">
                <label><input type="checkbox" id="showAll" onchange="updateTable()"> All</label>
            </div>
        </div>
        <table>
            <thead>
                <tr>
                    <th class="sortable sort-asc" data-sort="standing" onclick="sortBy('standing')">#</th>
                    <th class="sortable" data-sort="name" onclick="sortBy('name')">Player</th>
                    <th class="sortable" data-sort="honor" onclick="sortBy('honor')">Last Week Honor</th>
                    <th class="sortable" data-sort="pre_rp" onclick="sortBy('pre_rp')">Pre-Reset RP</th>
                    <th class="sortable" data-sort="pre_rank" onclick="sortBy('pre_rank')">Pre-Reset Rank</th>
                    <th class="sortable" data-sort="post_rp" onclick="sortBy('post_rp')">Post-Reset RP</th>
                    <th class="sortable" data-sort="award" onclick="sortBy('award')">Award</th>
                    <th class="sortable" data-sort="net_gain" onclick="sortBy('net_gain')">Net Gain</th>
                    <th class="sortable" data-sort="post_rank" onclick="sortBy('post_rank')">Post-Reset Rank</th>
                </tr>
            </thead>
            <tbody id="tableBody">
            </tbody>
        </table>
    </div>

    <script>
        // Detect API base URL dynamically
        const apiBase = window.location.hostname === 'honorspy.duckdns.org' ? '' : '/honorspy';

        let awards = {awards_json};

        // Sorting state for awards page
        let currentSort = {{ column: "standing", direction: "asc" }};
        awards.forEach((a, idx) => {{ a.originalStanding = a.standing || (idx + 1); }});
        let originalAwards = [...awards];

        function sortBy(column) {{
            const headers = document.querySelectorAll("th.sortable");

            if (currentSort.column === column) {{
                currentSort.direction = currentSort.direction === "asc" ? "desc" : "asc";
            }} else {{
                currentSort.column = column;
                currentSort.direction = column === "standing" ? "asc" : "desc";
            }}

            headers.forEach(h => {{
                h.classList.remove("sort-asc", "sort-desc");
                if (h.dataset.sort === column) {{
                    h.classList.add(currentSort.direction === "asc" ? "sort-asc" : "sort-desc");
                }}
            }});

            if (column === "standing") {{
                awards = [...originalAwards];
                if (currentSort.direction === "desc") {{
                    awards.reverse();
                }}
            }} else {{
                awards.sort((a, b) => {{
                    let valA, valB;
                    switch (column) {{
                        case "name":
                            valA = a.name.toLowerCase();
                            valB = b.name.toLowerCase();
                            break;
                        case "honor":
                            valA = a.pre_reset_honor || 0;
                            valB = b.pre_reset_honor || 0;
                            break;
                        case "pre_rp":
                            valA = a.pre_reset_rp || 0;
                            valB = b.pre_reset_rp || 0;
                            break;
                        case "pre_rank":
                            valA = a.pre_reset_rank || 0;
                            valB = b.pre_reset_rank || 0;
                            break;
                        case "post_rp":
                            valA = a.post_reset_rp || 0;
                            valB = b.post_reset_rp || 0;
                            break;
                        case "award":
                            valA = a.award || 0;
                            valB = b.award || 0;
                            break;
                        case "net_gain":
                            valA = a.net_gain || 0;
                            valB = b.net_gain || 0;
                            break;
                        case "post_rank":
                            valA = a.post_reset_rank || 0;
                            valB = b.post_reset_rank || 0;
                            break;
                        default:
                            valA = a.originalStanding;
                            valB = b.originalStanding;
                    }}

                    if (typeof valA === "string") {{
                        return currentSort.direction === "asc"
                            ? valA.localeCompare(valB)
                            : valB.localeCompare(valA);
                    }}
                    return currentSort.direction === "asc" ? valA - valB : valB - valA;
                }});
            }}

            updateTable();
        }}
        const weekPairs = {week_pairs_json};

        function formatNumber(num) {{
            return num.toLocaleString();
        }}

        function formatDate(dateStr) {{
            // Convert YYYY-MM-DD to readable format
            const [year, month, day] = dateStr.split('-');
            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            return `${{months[parseInt(month) - 1]}} ${{parseInt(day)}}, ${{year}}`;
        }}

        function populateWeekSelector() {{
            const selector = document.getElementById('weekSelector');
            selector.innerHTML = '';

            weekPairs.forEach((pair, index) => {{
                const option = document.createElement('option');
                const hasPost = pair.post_reset !== null;
                const dateLabel = formatDate(pair.week_date);

                if (hasPost) {{
                    option.value = JSON.stringify({{
                        pre: pair.pre_reset.filename,
                        post: pair.post_reset.filename
                    }});
                    option.textContent = `Week ending ${{dateLabel}} (${{pair.pre_reset.player_count}} players)`;
                }} else {{
                    option.value = 'no-post';
                    option.textContent = `Week ending ${{dateLabel}} (no post-reset data yet)`;
                    option.disabled = false;  // Allow selection to show message
                }}

                // Select first valid option by default
                if (index === 0 && hasPost) {{
                    option.selected = true;
                }}

                selector.appendChild(option);
            }});
        }}

        function showLoading(show) {{
            const overlay = document.getElementById('loadingOverlay');
            if (show) {{
                overlay.classList.remove('hidden');
            }} else {{
                overlay.classList.add('hidden');
            }}
        }}

        async function changeWeek() {{
            const selector = document.getElementById('weekSelector');
            const selectedValue = selector.value;
            const warning = document.getElementById('noDataWarning');
            const tableBody = document.getElementById('tableBody');

            if (selectedValue === 'no-post') {{
                warning.style.display = 'block';
                tableBody.innerHTML = '';
                document.getElementById('weekIndicator').textContent = 'No data';
                return;
            }}

            warning.style.display = 'none';
            showLoading(true);

            try {{
                const snapshots = JSON.parse(selectedValue);
                const response = await fetch(`${{apiBase}}/api/awards?pre=${{snapshots.pre}}&post=${{snapshots.post}}`);

                if (!response.ok) {{
                    throw new Error('Failed to load awards data');
                }}

                const data = await response.json();

                if (data.error) {{
                    throw new Error(data.error);
                }}

                awards = data.awards || [];

                // Update display
                document.getElementById('weekIndicator').textContent = `${{awards.length}} players`;
                document.getElementById('preDate').textContent = data.pre_snapshot_date || 'Unknown';
                document.getElementById('postDate').textContent = data.post_snapshot_date || 'Unknown';

                updateTable();
            }} catch (error) {{
                console.error('Error loading awards:', error);
                alert('Failed to load awards: ' + error.message);
            }} finally {{
                showLoading(false);
            }}
        }}

        function updateTable() {{
            const showAll = document.getElementById('showAll').checked;
            const count = showAll ? awards.length : (parseInt(document.getElementById('displayCount').value) || 50);
            const searchTerm = document.getElementById('playerSearch').value.toLowerCase().trim();
            const tbody = document.getElementById('tableBody');
            tbody.innerHTML = '';

            let displayed = 0;
            for (let i = 0; i < awards.length && displayed < count; i++) {{
                const a = awards[i];

                if (searchTerm && !a.name.toLowerCase().includes(searchTerm)) {{
                    continue;
                }}

                const rankPre = `R${{a.pre_reset_rank}} @ ${{(a.pre_reset_progress * 100).toFixed(1)}}%`;
                const rankPost = `R${{a.post_reset_rank}} @ ${{(a.post_reset_progress * 100).toFixed(1)}}%`;
                const netClass = a.net_gain >= 0 ? 'gain' : 'loss';

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="rank-col">${{a.standing}}</td>
                    <td class="class-${{a.class}}">${{a.name}}</td>
                    <td>${{formatNumber(a.pre_reset_honor)}}</td>
                    <td>${{formatNumber(a.pre_reset_rp)}}</td>
                    <td>${{rankPre}}</td>
                    <td>${{formatNumber(a.post_reset_rp)}}</td>
                    <td class="award-col">${{formatNumber(a.award)}}</td>
                    <td class="${{netClass}}-col">${{a.net_gain >= 0 ? '+' : ''}}${{formatNumber(a.net_gain)}}</td>
                    <td>${{rankPost}}</td>
                `;
                tbody.appendChild(row);
                displayed++;
            }}

            if (displayed === 0 && awards.length === 0) {{
                const row = document.createElement('tr');
                row.innerHTML = '<td colspan="9" style="text-align: center; color: #888;">No awards data available for this week</td>';
                tbody.appendChild(row);
            }}
        }}

        // Initialize
        // Set back link dynamically based on hostname
        document.getElementById('backLink').href = window.location.hostname === 'honorspy.duckdns.org' ? '/' : '/honorspy/';
        populateWeekSelector();
        updateTable();
    </script>
</body>
</html>'''

    return html


def generate_dashboard_html(merged_data):
    """Generate the HTML dashboard from merged data."""

    # Convert dict to sorted list
    all_players = list(merged_data.get('players', {}).values())
    all_players.sort(key=lambda x: x.get('thisWeekHonor', 0), reverse=True)

    # Calculate the most recent Tuesday 4 PM Pacific (reset time)
    # Reset happens every Tuesday at 4:00 PM Pacific = 00:00 UTC Wednesday
    now = datetime.now()
    # Find the most recent Tuesday
    days_since_tuesday = (now.weekday() - 1) % 7  # Tuesday is weekday 1
    if days_since_tuesday == 0 and now.hour < 16:  # Before 4 PM on Tuesday
        days_since_tuesday = 7
    last_reset = now.replace(hour=16, minute=0, second=0, microsecond=0)
    last_reset = last_reset - timedelta(days=days_since_tuesday)
    reset_timestamp = int(last_reset.timestamp())

    # For "Current Week" view, only show players checked AFTER the reset AND with thisWeekHonor > 0
    players = [p for p in all_players if p.get('last_checked', 0) >= reset_timestamp and p.get('thisWeekHonor', 0) > 0]

    pool_size = len(players)
    bracket_14_spots = math.floor(pool_size * 0.003 + 0.5) if pool_size > 0 else 0

    # Get contributor stats
    contributors = merged_data.get('contributors', {})
    contributor_count = len(contributors)
    last_updated = merged_data.get('last_updated', 0)
    last_updated_str = datetime.fromtimestamp(last_updated).strftime('%Y-%m-%d %H:%M:%S') if last_updated else 'Never'

    # Load awards data for hover tooltips
    awards_data, _ = calculate_awards()
    awards_by_name = {}
    if awards_data:
        for a in awards_data.get('awards', []):
            awards_by_name[a['name']] = a

    # Get available snapshots for week selector
    snapshots = get_snapshots()
    # Filter to only pre_reset snapshots (these represent finalized weeks)
    week_snapshots = [s for s in snapshots if s.get('label') == 'pre_reset']
    snapshots_json = json.dumps(week_snapshots)

    # Convert players to JSON-safe format
    players_json = json.dumps(players)
    all_players_json = json.dumps(all_players)
    contributors_json = json.dumps(contributors)
    awards_json = json.dumps(awards_by_name)
    reset_timestamp_json = reset_timestamp

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HonorSpy Dashboard - Turtle WoW</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #eee;
            padding: 10px 15px;
            font-size: 14px;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }}
        h1 {{
            color: #ffd700;
            font-size: 1.5em;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
        }}
        .subtitle {{
            color: #888;
            font-size: 0.85em;
        }}
        
        .top-section {{
            display: flex;
            gap: 15px;
            margin-bottom: 10px;
            align-items: stretch;
        }}
        .stats-grid {{
            display: flex;
            gap: 10px;
        }}
        .stat-card {{
            background: rgba(255,255,255,0.1);
            border-radius: 6px;
            padding: 8px 15px;
            text-align: center;
            border: 1px solid rgba(255,215,0,0.3);
        }}
        .stat-card h3 {{
            color: #ffd700;
            font-size: 1.6em;
            margin-bottom: 2px;
        }}
        .stat-card p {{
            color: #aaa;
            font-size: 0.75em;
        }}
        .controls {{
            background: rgba(255,255,255,0.05);
            border-radius: 6px;
            padding: 8px 12px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex: 1;
        }}
        .control-group {{
            display: flex;
            align-items: center;
            gap: 5px;
        }}
        .control-group label {{
            color: #ffd700;
            font-weight: bold;
            font-size: 0.85em;
        }}
        .control-group input:not([type="checkbox"]) {{
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,215,0,0.5);
            border-radius: 4px;
            padding: 4px 8px;
            color: #fff;
            width: 50px;
            font-size: 0.9em;
        }}
        .control-group input[type="text"] {{
            width: 120px;
        }}
        .control-group input:focus {{
            outline: none;
            border-color: #ffd700;
        }}
        .control-group select {{
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,215,0,0.5);
            border-radius: 4px;
            padding: 4px 8px;
            color: #fff;
            font-size: 0.9em;
            cursor: pointer;
        }}
        .control-group select:focus {{
            outline: none;
            border-color: #ffd700;
        }}
        .control-group select option {{
            background: #1a1a2e;
            color: #fff;
        }}
        .week-indicator {{
            background: rgba(255,215,0,0.2);
            color: #ffd700;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 0.85em;
            font-weight: bold;
        }}
        .loading-overlay {{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }}
        .loading-overlay.hidden {{
            display: none;
        }}
        .loading-spinner {{
            color: #ffd700;
            font-size: 1.2em;
        }}
        .main-content {{
            display: flex;
            gap: 15px;
        }}
        .table-container {{
            flex: 1;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            background: rgba(255,255,255,0.05);
            border-radius: 6px;
            overflow: hidden;
            font-size: 1.1em;
        }}
        th {{
            background: rgba(255,215,0,0.2);
            color: #ffd700;
            padding: 6px 8px;
            text-align: left;
            font-weight: bold;
            font-size: 0.85em;
        }}
        td {{
            padding: 5px 8px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }}
        tr:hover {{
            background: rgba(255,215,0,0.1);
        }}
        tr.bracket-14 {{
            background: rgba(0,255,0,0.1);
        }}
        tr.bracket-14:hover {{
            background: rgba(0,255,0,0.2);
        }}
        .rank-col {{
            font-weight: bold;
            color: #ffd700;
        }}
        .honor-col {{
            color: #4fc3f7;
            font-weight: bold;
        }}
        .class-WARRIOR {{ color: #C79C6E; }}
        .class-PALADIN {{ color: #F58CBA; }}
        .class-HUNTER {{ color: #ABD473; }}
        .class-ROGUE {{ color: #FFF569; }}
        .class-PRIEST {{ color: #FFFFFF; }}
        .class-SHAMAN {{ color: #0070DE; }}
        .class-MAGE {{ color: #69CCF0; }}
        .class-WARLOCK {{ color: #9482C9; }}
        .class-DRUID {{ color: #FF7D0A; }}
        .bracket-col {{ color: #aaa; }}
        .decay-col {{ color: #ff6b6b; }}
        .gain-col {{ color: #51cf66; }}
        .loss-col {{ color: #ff6b6b; }}
        .projected-col {{ color: #ffd700; font-weight: bold; }}
        .updated-col {{ color: #888; font-size: 0.85em; }}
        .updated-recent {{ color: #51cf66; }}
        .updated-old {{ color: #ff6b6b; }}
        .bracket-analysis {{
            background: rgba(255,255,255,0.05);
            border-radius: 6px;
            padding: 10px;
            min-width: 280px;
        }}
        .bracket-analysis h2 {{
            color: #ffd700;
            margin-bottom: 8px;
            font-size: 1em;
        }}
        .bracket-table {{
            width: 100%;
            font-size: 0.85em;
        }}
        .bracket-table th, .bracket-table td {{
            padding: 5px 8px;
        }}
        .highlight {{
            color: #4fc3f7;
            font-weight: bold;
        }}
        .refresh-btn {{
            background: linear-gradient(135deg, #ffd700 0%, #ffaa00 100%);
            color: #1a1a2e;
            border: none;
            padding: 5px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 0.85em;
        }}
        .refresh-btn:hover {{
            transform: scale(1.02);
        }}
        .tooltip {{
            position: fixed;
            background: rgba(0, 0, 0, 0.95);
            border: 1px solid #ffd700;
            border-radius: 6px;
            padding: 10px 12px;
            color: #eee;
            font-size: 0.85em;
            z-index: 1000;
            pointer-events: none;
            display: none;
            min-width: 220px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        }}
        .tooltip h4 {{
            color: #ffd700;
            margin-bottom: 8px;
            font-size: 1em;
            border-bottom: 1px solid rgba(255,215,0,0.3);
            padding-bottom: 5px;
        }}
        .tooltip-row {{
            display: flex;
            justify-content: space-between;
            margin: 4px 0;
        }}
        .tooltip-label {{
            color: #888;
        }}
        .tooltip-value {{
            color: #fff;
            font-weight: bold;
        }}
        .tooltip-award {{
            color: #51cf66;
        }}
        .tooltip-net-gain {{
            color: #51cf66;
        }}
        .tooltip-net-loss {{
            color: #ff6b6b;
        }}
        .tooltip-no-data {{
            color: #888;
            font-style: italic;
        }}
        .contributor-badge {{
            background: rgba(0,255,0,0.2);
            color: #51cf66;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            margin-left: 10px;
            cursor: pointer;
            position: relative;
        }}
        .contributor-badge:hover {{
            background: rgba(0,255,0,0.3);
        }}
        .contributor-popup {{
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: rgba(0, 0, 0, 0.95);
            border: 1px solid #ffd700;
            border-radius: 6px;
            padding: 10px 15px;
            min-width: 250px;
            z-index: 1000;
            margin-top: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        }}
        .contributor-popup.show {{
            display: block;
        }}
        .contributor-popup h4 {{
            color: #ffd700;
            margin-bottom: 10px;
            font-size: 0.95em;
            border-bottom: 1px solid rgba(255,215,0,0.3);
            padding-bottom: 5px;
        }}
        .contributor-item {{
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }}
        .contributor-item:last-child {{
            border-bottom: none;
        }}
        .contributor-name {{
            color: #51cf66;
            font-weight: bold;
        }}
        .contributor-info {{
            color: #888;
            font-size: 0.85em;
        }}
        /* Sortable column headers - Added Dec 9, 2025 */
        th.sortable {{
            cursor: pointer;
            user-select: none;
            position: relative;
            padding-right: 18px !important;
        }}
        th.sortable:hover {{
            background: #333;
        }}
        th.sortable::after {{
            content: "";
            position: absolute;
            right: 4px;
            opacity: 0.3;
            font-size: 0.75em;
        }}
        th.sortable.sort-asc::after {{
            content: " ^";
            opacity: 1;
            color: #4dabf7;
        }}
        th.sortable.sort-desc::after {{
            content: " v";
            opacity: 1;
            color: #4dabf7;
        }}
    </style>
</head>
<body>
    <div id="loadingOverlay" class="loading-overlay hidden">
        <div class="loading-spinner">Loading week data...</div>
    </div>
    <div id="tooltip" class="tooltip"></div>
    <div class="container">
        <div class="header">
            <div>
                <h1>HonorSpy Dashboard</h1>
                <span class="week-indicator" id="weekIndicator">Current Week</span>
                <span class="contributor-badge" onclick="toggleContributorPopup(event)">
                    {contributor_count} contributor(s)
                    <div class="contributor-popup" id="contributorPopup">
                        <h4>Contributors</h4>
                        <div id="contributorList"></div>
                    </div>
                </span>
            </div>
            <div>
                <span class="subtitle">{last_updated_str} | Horde</span>
                <a href="/awards.html" onclick="this.href = window.location.hostname === 'honorspy.duckdns.org' ? '/awards.html' : '/honorspy/awards.html'; return true;" style="color: #4fc3f7; margin-left: 15px; text-decoration: none; font-size: 0.85em;">View Weekly Awards →</a>
            </div>
        </div>

        <div class="top-section">
            <div class="stats-grid">
                <div class="stat-card">
                    <h3 id="poolSize">{pool_size:,}</h3>
                    <p>Pool Size</p>
                </div>
                <div class="stat-card">
                    <h3 id="bracketSpots">{bracket_14_spots}</h3>
                    <p>B14 Spots</p>
                </div>
                <div class="stat-card">
                    <h3 id="nextSpotNeeded">--</h3>
                    <p>For +1 Spot</p>
                </div>
            </div>
            <div class="controls">
                <div class="control-group">
                    <label>Week:</label>
                    <select id="weekSelector" onchange="changeWeek()">
                        <option value="current">Current Week</option>
                    </select>
                </div>
                <div class="control-group">
                    <label>Search:</label>
                    <input type="text" id="playerSearch" placeholder="Player name..." oninput="updateTable()">
                </div>
                <div class="control-group">
                    <label>Show:</label>
                    <input type="number" id="playerCount" value="10" min="1" max="100" onchange="updateTable()">
                </div>
                <div class="control-group">
                    <label><input type="checkbox" id="showAll" onchange="updateTable()"> All</label>
                </div>
                <div class="control-group">
                    <label>Calc Spots:</label>
                    <input type="number" id="additionalSpots" value="2" min="1" max="10" onchange="updateBracketAnalysis()">
                </div>
                <div class="control-group">
                    <label>Simulate:</label>
                    <input type="text" id="simHonor" placeholder="Honor amount..." oninput="updateTable()">
                </div>
                <button class="refresh-btn" onclick="location.reload()">Refresh</button>
            </div>
        </div>

        <div class="main-content">

        <div class="table-container">
            <table id="standingsTable">
                <thead>
                    <tr>
                        <th class="sortable sort-asc" data-sort="standing" onclick="sortBy('standing')">#</th>
                        <th class="sortable" data-sort="name" onclick="sortBy('name')">Player</th>
                        <th class="sortable" data-sort="rank" onclick="sortBy('rank')">Rank</th>
                        <th class="sortable" data-sort="rp" onclick="sortBy('rp')">RP</th>
                        <th class="sortable" data-sort="honor" onclick="sortBy('honor')">Honor</th>
                        <th class="sortable" data-sort="updated" onclick="sortBy('updated')">Updated</th>
                        <th class="sortable" data-sort="bracket" onclick="sortBy('bracket')">B</th>
                        <th class="sortable" data-sort="decay" onclick="sortBy('decay')">Decay</th>
                        <th class="sortable" data-sort="gain" onclick="sortBy('gain')">Gain</th>
                        <th class="sortable" data-sort="net" onclick="sortBy('net')">Net</th>
                        <th class="sortable" data-sort="projected" onclick="sortBy('projected')">Projected</th>
                    </tr>
                </thead>
                <tbody id="tableBody">
                </tbody>
            </table>
        </div>

        <div class="bracket-analysis">
            <h2>Bracket 14 Spots</h2>
            <table class="bracket-table" id="bracketTable">
                <thead>
                    <tr>
                        <th>Target</th>
                        <th>Pool</th>
                        <th>+Players</th>
                    </tr>
                </thead>
                <tbody id="bracketBody">
                </tbody>
            </table>
        </div>
        </div>
    </div>

    <script>
        // Detect API base URL dynamically
        const apiBase = window.location.hostname === 'honorspy.duckdns.org' ? '' : '/honorspy';

        let players = {players_json};

        // Sorting state - Added Dec 9, 2025
        let currentSort = {{ column: "standing", direction: "asc" }};
        // Store original standing on each player so sorting doesn't break calculations
        players.forEach((p, idx) => {{ p.originalStanding = idx + 1; }});
        let originalPlayers = [...players]; // Keep original order for standing sort
        const allPlayers = {all_players_json};
        const contributors = {contributors_json};
        const awardsData = {awards_json};
        let poolSize = {pool_size};
        let currentSpots = {bracket_14_spots};
        const tooltip = document.getElementById('tooltip');
        const weekSnapshots = {snapshots_json};
        const resetTimestamp = {reset_timestamp_json};
        let currentWeekMode = 'current';
        let snapshotDateText = '';

        // Bracket thresholds (cumulative from top) and RP gains
        const bracketData = [
            {{ bracket: 14, threshold: 0.003, rpMin: 12000, rpMax: 13000 }},
            {{ bracket: 13, threshold: 0.008, rpMin: 11000, rpMax: 12000 }},
            {{ bracket: 12, threshold: 0.020, rpMin: 10000, rpMax: 11000 }},
            {{ bracket: 11, threshold: 0.035, rpMin: 9000, rpMax: 10000 }},
            {{ bracket: 10, threshold: 0.060, rpMin: 8000, rpMax: 9000 }},
            {{ bracket: 9,  threshold: 0.100, rpMin: 7000, rpMax: 8000 }},
            {{ bracket: 8,  threshold: 0.159, rpMin: 6000, rpMax: 7000 }},
            {{ bracket: 7,  threshold: 0.228, rpMin: 5000, rpMax: 6000 }},
            {{ bracket: 6,  threshold: 0.327, rpMin: 4000, rpMax: 5000 }},
            {{ bracket: 5,  threshold: 0.436, rpMin: 3000, rpMax: 4000 }},
            {{ bracket: 4,  threshold: 0.566, rpMin: 2000, rpMax: 3000 }},
            {{ bracket: 3,  threshold: 0.697, rpMin: 1000, rpMax: 2000 }},
            {{ bracket: 2,  threshold: 0.845, rpMin: 400, rpMax: 1000 }},
            {{ bracket: 1,  threshold: 1.000, rpMin: 0, rpMax: 400 }}
        ];

        // Rank RP thresholds (R1=0, R2=2000, then +5000 each)
        const rankThresholds = [0, 0, 2000, 5000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000];

        function formatRelativeTime(timestamp) {{
            if (!timestamp) return '?';
            const now = Math.floor(Date.now() / 1000);
            const diff = now - timestamp;

            if (diff < 60) return 'now';
            if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
            if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
            if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
            return Math.floor(diff / 604800) + 'w ago';
        }}

        function getUpdatedClass(timestamp) {{
            if (!timestamp) return 'updated-col';
            const now = Math.floor(Date.now() / 1000);
            const diff = now - timestamp;

            if (diff < 3600) return 'updated-col updated-recent';  // Less than 1 hour = green
            if (diff > 86400) return 'updated-col updated-old';    // More than 1 day = red
            return 'updated-col';
        }}

        function getBracket(standing) {{
            // Use same rounding logic as B14 spots calculation for consistency
            for (const b of bracketData) {{
                const cutoff = Math.floor(poolSize * b.threshold + 0.5);
                if (standing <= cutoff) return b;
            }}
            return bracketData[bracketData.length - 1];
        }}

        function getRpGain(standing, bracket, playerHonor) {{
            // ============================================================
            // REFINED RP FORMULA - Updated Dec 8, 2025
            // Based on reverse engineering from actual Turtle WoW data
            // See: docs/REFINED_FORMULA_2025-12-04.md
            // ============================================================
            // Key findings:
            // - Actual bracket ranges are COMPRESSED (not full 1000 RP)
            // - Floor boost varies by bracket (+498 for B14, +451 for B13)
            // - Honor position within bracket is primary factor
            // ============================================================

            const prevThreshold = bracketData.find(b => b.bracket === bracket.bracket + 1)?.threshold || 0;
            const bracketStartStanding = Math.floor(poolSize * prevThreshold + 0.5) + 1;
            const bracketEndStanding = Math.floor(poolSize * bracket.threshold + 0.5);

            // Get all players in this bracket
            const bracketPlayers = players.slice(bracketStartStanding - 1, bracketEndStanding);

            if (bracketPlayers.length <= 1) return bracket.rpMax;

            // Find min and max honor in this bracket
            const maxHonor = bracketPlayers[0].thisWeekHonor;
            const minHonor = bracketPlayers[bracketPlayers.length - 1].thisWeekHonor;
            const honorRange = maxHonor - minHonor;

            if (honorRange === 0) return bracket.rpMax;

            // Calculate honor position within bracket (0 = bottom, 1 = top)
            const honorPosition = Math.max(0, Math.min(1, (playerHonor - minHonor) / honorRange));

            // REFINED: Use actual observed ranges instead of official 1000 RP spread
            // Data from Dec 2-3, 2025 reset analysis:
            // B14: actual 12,498-13,011 (spread 513, floor boost +498)
            // B13: actual 11,451-12,145 (spread 694, floor boost +451)
            // B12: actual 10,129-11,364 (spread 1235, floor boost +129)
            // B11: actual 9,270-10,184 (spread 914, floor boost +270)
            const refinedBrackets = {{
                14: {{ floor: 12498, ceiling: 13000, spread: 502 }},
                13: {{ floor: 11451, ceiling: 12145, spread: 694 }},
                12: {{ floor: 10129, ceiling: 11000, spread: 871 }},
                11: {{ floor: 9270, ceiling: 10000, spread: 730 }},
                10: {{ floor: 8200, ceiling: 9000, spread: 800 }},
                9:  {{ floor: 7150, ceiling: 8000, spread: 850 }},
                8:  {{ floor: 6100, ceiling: 7000, spread: 900 }},
                7:  {{ floor: 5050, ceiling: 6000, spread: 950 }},
                6:  {{ floor: 4000, ceiling: 5000, spread: 1000 }}
            }};

            const refined = refinedBrackets[bracket.bracket];
            if (refined) {{
                // Use refined formula with actual observed values
                const actualRp = refined.floor + (refined.spread * honorPosition);
                return Math.round(actualRp);
            }}

            // Fallback for brackets without refined data
            const rpRange = bracket.rpMax - bracket.rpMin;
            const baseRp = bracket.rpMin + (rpRange * honorPosition);
            const floorBoost = 250 * Math.pow(1 - honorPosition, 2);
            return Math.round(baseRp + floorBoost);
        }}

        function getProjectedRank(newRp, currentRank) {{
            // TurtleWow rule: You CANNOT lose rank number, only progress within rank
            // A player at R13 can decay to R13 @ 0%, but NEVER to R12

            // Calculate what rank the RP would give
            let calculatedRank = 1;
            let calculatedProgress = 0;

            for (let r = 14; r >= 1; r--) {{
                if (newRp >= rankThresholds[r]) {{
                    calculatedRank = r;
                    calculatedProgress = (newRp - rankThresholds[r]) / 5000;
                    break;
                }}
            }}

            // Enforce no rank regression: can't drop below current rank
            if (calculatedRank < currentRank) {{
                // Clamp to current rank @ 0%
                return {{ rank: currentRank, progress: 0 }};
            }}

            return {{ rank: calculatedRank, progress: Math.min(calculatedProgress, 0.999) }};
        }}

        function getSimulatedStanding(playerName, simHonor) {{
            const simPlayers = players.map(p => ({{
                ...p,
                simHonor: p.name.toLowerCase() === playerName.toLowerCase() ? simHonor : p.thisWeekHonor
            }}));
            simPlayers.sort((a, b) => b.simHonor - a.simHonor);
            for (let i = 0; i < simPlayers.length; i++) {{
                if (simPlayers[i].name.toLowerCase() === playerName.toLowerCase()) {{
                    return i + 1;
                }}
            }}
            return -1;
        }}

        function calculateSpotsNeeded(targetSpots) {{
            const poolNeeded = Math.ceil((targetSpots - 0.5) / 0.003);
            return poolNeeded;
        }}

        function formatNumber(num) {{
            return num.toLocaleString();
        }}


        // Sort function - Added Dec 9, 2025
        function sortBy(column) {{
            const headers = document.querySelectorAll("th.sortable");

            // Toggle direction if same column, else default to desc (except standing defaults to asc)
            if (currentSort.column === column) {{
                currentSort.direction = currentSort.direction === "asc" ? "desc" : "asc";
            }} else {{
                currentSort.column = column;
                currentSort.direction = column === "standing" ? "asc" : "desc";
            }}

            // Update header classes
            headers.forEach(h => {{
                h.classList.remove("sort-asc", "sort-desc");
                if (h.dataset.sort === column) {{
                    h.classList.add(currentSort.direction === "asc" ? "sort-asc" : "sort-desc");
                }}
            }});

            // Sort the players array
            if (column === "standing") {{
                // Restore original order for standing
                players = [...originalPlayers];
                if (currentSort.direction === "desc") {{
                    players.reverse();
                }}
            }} else {{
                players.sort((a, b) => {{
                    let valA, valB;
                    switch (column) {{
                        case "name":
                            valA = a.name.toLowerCase();
                            valB = b.name.toLowerCase();
                            break;
                        case "rank":
                            valA = a.rank + a.progress;
                            valB = b.rank + b.progress;
                            break;
                        case "rp":
                            valA = a.RP;
                            valB = b.RP;
                            break;
                        case "honor":
                            valA = a.thisWeekHonor;
                            valB = b.thisWeekHonor;
                            break;
                        case "bracket":
                            valA = getBracket(a.originalStanding).bracket;
                            valB = getBracket(b.originalStanding).bracket;
                            break;
                        case "net":
                            const bracketA = getBracket(a.originalStanding);
                            const bracketB = getBracket(b.originalStanding);
                            const decayA = Math.round(a.RP * 0.20);
                            const decayB = Math.round(b.RP * 0.20);
                            valA = getRpGain(a.originalStanding, bracketA, a.thisWeekHonor) - decayA;
                            valB = getRpGain(b.originalStanding, bracketB, b.thisWeekHonor) - decayB;
                            break;
                        case "updated":
                            // Sort by last_checked timestamp (newer = higher value)
                            valA = a.last_checked || 0;
                            valB = b.last_checked || 0;
                            break;
                        case "decay":
                            // Decay is 20% of RP
                            valA = Math.round(a.RP * 0.20);
                            valB = Math.round(b.RP * 0.20);
                            break;
                        case "gain":
                            // RP gain based on standing and bracket
                            const gainBracketA = getBracket(a.originalStanding);
                            const gainBracketB = getBracket(b.originalStanding);
                            valA = getRpGain(a.originalStanding, gainBracketA, a.thisWeekHonor);
                            valB = getRpGain(b.originalStanding, gainBracketB, b.thisWeekHonor);
                            break;
                        case "projected":
                            // Projected rank after reset
                            const projBracketA = getBracket(a.originalStanding);
                            const projBracketB = getBracket(b.originalStanding);
                            const projDecayA = Math.round(a.RP * 0.20);
                            const projDecayB = Math.round(b.RP * 0.20);
                            const projGainA = getRpGain(a.originalStanding, projBracketA, a.thisWeekHonor);
                            const projGainB = getRpGain(b.originalStanding, projBracketB, b.thisWeekHonor);
                            const newRpA = a.RP + projGainA - projDecayA;
                            const newRpB = b.RP + projGainB - projDecayB;
                            valA = newRpA;
                            valB = newRpB;
                            break;
                        default:
                            valA = 0;
                            valB = 0;
                    }}

                    if (typeof valA === "string") {{
                        return currentSort.direction === "asc"
                            ? valA.localeCompare(valB)
                            : valB.localeCompare(valA);
                    }}
                    return currentSort.direction === "asc" ? valA - valB : valB - valA;
                }});
            }}

            updateTable();
        }}

        function updateTable() {{
            const showAll = document.getElementById('showAll').checked;
            const count = showAll ? players.length : (parseInt(document.getElementById('playerCount').value) || 10);
            const searchTerm = document.getElementById('playerSearch').value.toLowerCase().trim();
            const simHonorStr = document.getElementById('simHonor').value.replace(/,/g, '').trim();
            const simHonor = simHonorStr ? parseInt(simHonorStr) : null;
            const tbody = document.getElementById('tableBody');
            tbody.innerHTML = '';

            let displayed = 0;
            for (let i = 0; i < players.length && displayed < count; i++) {{
                const p = players[i];

                if (searchTerm && !p.name.toLowerCase().includes(searchTerm)) {{
                    continue;
                }}

                const standing = p.originalStanding || (i + 1);
                const inBracket14 = i < currentSpots;
                const pct = (p.progress * 100).toFixed(1);

                const bracket = getBracket(standing);
                const decay = Math.round(p.RP * 0.20);
                const rpGain = getRpGain(standing, bracket, p.thisWeekHonor);
                const netChange = rpGain - decay;
                const newRp = p.RP + netChange;
                const projected = getProjectedRank(newRp, p.rank);
                const projPct = (projected.progress * 100).toFixed(1);

                const updatedText = currentWeekMode === 'snapshot' ? snapshotDateText : formatRelativeTime(p.last_checked);
                const updatedClass = getUpdatedClass(p.last_checked);

                const row = document.createElement('tr');
                if (inBracket14) row.classList.add('bracket-14');
                row.dataset.playerName = p.name;

                const netClass = netChange >= 0 ? 'gain' : 'loss';
                row.innerHTML = `
                    <td class="rank-col">${{standing}}</td>
                    <td class="class-${{p.class || 'Unknown'}}">${{p.name}}</td>
                    <td>R${{p.rank}} @ ${{pct}}%</td>
                    <td>${{formatNumber(p.RP)}}</td>
                    <td class="honor-col">${{formatNumber(p.thisWeekHonor)}}</td>
                    <td class="${{updatedClass}}">${{updatedText}}</td>
                    <td class="bracket-col">B${{bracket.bracket}}</td>
                    <td class="decay-col">-${{formatNumber(decay)}}</td>
                    <td class="gain-col">+${{formatNumber(rpGain)}}</td>
                    <td class="${{netClass}}-col">${{netChange >= 0 ? '+' : ''}}${{formatNumber(netChange)}}</td>
                    <td class="projected-col">R${{projected.rank}} @ ${{projPct}}%</td>
                `;

                // Add hover events for tooltip
                row.addEventListener('mouseenter', (e) => showTooltip(e, p.name));
                row.addEventListener('mousemove', (e) => moveTooltip(e));
                row.addEventListener('mouseleave', hideTooltip);

                tbody.appendChild(row);
                displayed++;

                if (simHonor && searchTerm && p.name.toLowerCase().includes(searchTerm)) {{
                    const simStanding = getSimulatedStanding(p.name, simHonor);
                    const simBracket = getBracket(simStanding);
                    const simRpGain = getRpGain(simStanding, simBracket, simHonor);
                    const simNetChange = simRpGain - decay;
                    const simNewRp = p.RP + simNetChange;
                    const simProjected = getProjectedRank(simNewRp, p.rank);
                    const simProjPct = (simProjected.progress * 100).toFixed(1);

                    const simRow = document.createElement('tr');
                    simRow.style.background = 'rgba(255, 165, 0, 0.2)';
                    simRow.style.borderLeft = '3px solid #ffa500';

                    const simNetClass = simNetChange >= 0 ? 'gain' : 'loss';
                    simRow.innerHTML = `
                        <td class="rank-col" style="color: #ffa500;">#${{simStanding}}</td>
                        <td style="color: #ffa500; font-style: italic;">IF ${{formatNumber(simHonor)}} honor</td>
                        <td>--</td>
                        <td>--</td>
                        <td class="honor-col" style="color: #ffa500;">${{formatNumber(simHonor)}}</td>
                        <td>--</td>
                        <td class="bracket-col" style="color: #ffa500;">B${{simBracket.bracket}}</td>
                        <td class="decay-col">-${{formatNumber(decay)}}</td>
                        <td class="gain-col">+${{formatNumber(simRpGain)}}</td>
                        <td class="${{simNetClass}}-col">${{simNetChange >= 0 ? '+' : ''}}${{formatNumber(simNetChange)}}</td>
                        <td class="projected-col" style="color: #ffa500;">R${{simProjected.rank}} @ ${{simProjPct}}%</td>
                    `;
                    tbody.appendChild(simRow);
                }}
            }}
        }}

        function updateBracketAnalysis() {{
            const additionalSpots = parseInt(document.getElementById('additionalSpots').value) || 1;
            const tbody = document.getElementById('bracketBody');
            tbody.innerHTML = '';

            const currentRow = document.createElement('tr');
            currentRow.innerHTML = `
                <td><strong>Current</strong></td>
                <td class="highlight">${{formatNumber(poolSize)}}</td>
                <td>--</td>
            `;
            tbody.appendChild(currentRow);

            for (let i = 1; i <= additionalSpots; i++) {{
                const targetSpots = currentSpots + i;
                const poolNeeded = calculateSpotsNeeded(targetSpots);
                const playersToAdd = poolNeeded - poolSize;

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${{targetSpots}} spots (+${{i}})</td>
                    <td>${{formatNumber(poolNeeded)}}</td>
                    <td class="highlight">+${{formatNumber(playersToAdd)}} players</td>
                `;
                tbody.appendChild(row);
            }}

            const nextPoolNeeded = calculateSpotsNeeded(currentSpots + 1);
            document.getElementById('nextSpotNeeded').textContent = '+' + formatNumber(nextPoolNeeded - poolSize);
        }}

        function showTooltip(e, playerName) {{
            const data = awardsData[playerName];

            if (!data) {{
                tooltip.innerHTML = `
                    <h4>${{playerName}}</h4>
                    <div class="tooltip-no-data">No award data available</div>
                    <div class="tooltip-no-data" style="font-size: 0.8em; margin-top: 5px;">
                        (Player may not have been in last week's snapshot)
                    </div>
                `;
            }} else {{
                const netClass = data.net_gain >= 0 ? 'tooltip-net-gain' : 'tooltip-net-loss';
                const netPrefix = data.net_gain >= 0 ? '+' : '';

                tooltip.innerHTML = `
                    <h4>Last Week: ${{playerName}}</h4>
                    <div class="tooltip-row">
                        <span class="tooltip-label">Standing:</span>
                        <span class="tooltip-value">#${{data.standing}}</span>
                    </div>
                    <div class="tooltip-row">
                        <span class="tooltip-label">Honor:</span>
                        <span class="tooltip-value">${{formatNumber(data.pre_reset_honor)}}</span>
                    </div>
                    <div class="tooltip-row">
                        <span class="tooltip-label">Pre-Reset RP:</span>
                        <span class="tooltip-value">${{formatNumber(data.pre_reset_rp)}}</span>
                    </div>
                    <div class="tooltip-row">
                        <span class="tooltip-label">Post-Reset RP:</span>
                        <span class="tooltip-value">${{formatNumber(data.post_reset_rp)}}</span>
                    </div>
                    <div class="tooltip-row" style="border-top: 1px solid rgba(255,215,0,0.3); padding-top: 5px; margin-top: 5px;">
                        <span class="tooltip-label">Award:</span>
                        <span class="tooltip-value tooltip-award">+${{formatNumber(data.award)}}</span>
                    </div>
                    <div class="tooltip-row">
                        <span class="tooltip-label">Net Change:</span>
                        <span class="tooltip-value ${{netClass}}">${{netPrefix}}${{formatNumber(data.net_gain)}}</span>
                    </div>
                `;
            }}

            tooltip.style.display = 'block';
            moveTooltip(e);
        }}

        function moveTooltip(e) {{
            const padding = 15;
            let x = e.clientX + padding;
            let y = e.clientY + padding;

            // Prevent tooltip from going off-screen
            const rect = tooltip.getBoundingClientRect();
            const tooltipWidth = rect.width || 220;
            const tooltipHeight = rect.height || 200;

            if (x + tooltipWidth > window.innerWidth) {{
                x = e.clientX - tooltipWidth - padding;
            }}
            if (y + tooltipHeight > window.innerHeight) {{
                y = e.clientY - tooltipHeight - padding;
            }}

            tooltip.style.left = x + 'px';
            tooltip.style.top = y + 'px';
        }}

        function hideTooltip() {{
            tooltip.style.display = 'none';
        }}

        function toggleContributorPopup(event) {{
            event.stopPropagation();
            const popup = document.getElementById('contributorPopup');
            popup.classList.toggle('show');

            if (popup.classList.contains('show')) {{
                // Populate contributor list
                const listDiv = document.getElementById('contributorList');
                listDiv.innerHTML = '';

                for (const [name, info] of Object.entries(contributors)) {{
                    const lastUpload = new Date(info.last_upload * 1000);
                    const timeAgo = formatRelativeTime(info.last_upload);
                    const item = document.createElement('div');
                    item.className = 'contributor-item';
                    item.innerHTML = `
                        <span class="contributor-name">${{name}}</span>
                        <span class="contributor-info">${{info.players_submitted}} players, ${{timeAgo}}</span>
                    `;
                    listDiv.appendChild(item);
                }}
            }}
        }}

        // Close popup when clicking outside
        document.addEventListener('click', function(event) {{
            const popup = document.getElementById('contributorPopup');
            if (popup && !event.target.closest('.contributor-badge')) {{
                popup.classList.remove('show');
            }}
        }});

        function populateWeekSelector() {{
            const selector = document.getElementById('weekSelector');
            // Keep the current week option, add past weeks
            weekSnapshots.forEach(snap => {{
                const option = document.createElement('option');
                option.value = snap.filename;
                // Parse the date from filename format: 2025-12-02_15-55
                const datePart = snap.date.split('_')[0]; // Get just the date part
                const [year, month, day] = datePart.split('-');
                const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                const monthName = months[parseInt(month) - 1];
                option.textContent = `Week ending ${{monthName}} ${{parseInt(day)}}, ${{year}} (${{snap.player_count.toLocaleString()}} players)`;
                selector.appendChild(option);
            }});
        }}

        function showLoading(show) {{
            const overlay = document.getElementById('loadingOverlay');
            if (show) {{
                overlay.classList.remove('hidden');
            }} else {{
                overlay.classList.add('hidden');
            }}
        }}

        async function changeWeek() {{
            const selector = document.getElementById('weekSelector');
            const selectedValue = selector.value;
            const weekIndicator = document.getElementById('weekIndicator');

            if (selectedValue === 'current') {{
                // Switch to current week (filtered to last_checked >= resetTimestamp AND thisWeekHonor > 0)
                currentWeekMode = 'current';
                players = allPlayers.filter(p => (p.last_checked || 0) >= resetTimestamp && p.thisWeekHonor > 0);
                poolSize = players.length;
                currentSpots = Math.floor(poolSize * 0.003 + 0.5);
                weekIndicator.textContent = 'Current Week';

                // Update stats
                document.getElementById('poolSize').textContent = poolSize.toLocaleString();
                document.getElementById('bracketSpots').textContent = currentSpots;

                updateTable();
                updateBracketAnalysis();
                return;
            }}

            // Load past week data from snapshot
            showLoading(true);
            currentWeekMode = 'snapshot';

            try {{
                const response = await fetch(`${{apiBase}}/api/snapshot/${{selectedValue}}`);
                if (!response.ok) {{
                    throw new Error('Failed to load snapshot');
                }}
                const data = await response.json();

                players = data.players;
                poolSize = players.length;
                currentSpots = Math.floor(poolSize * 0.003 + 0.5);

                // Update the week indicator
                const datePart = data.date.split('_')[0];
                const [year, month, day] = datePart.split('-');
                const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                const monthName = months[parseInt(month) - 1];
                snapshotDateText = `${{monthName}} ${{parseInt(day)}}`;
                weekIndicator.textContent = `Week ending ${{snapshotDateText}}`;

                // Update stats
                document.getElementById('poolSize').textContent = poolSize.toLocaleString();
                document.getElementById('bracketSpots').textContent = currentSpots;

                updateTable();
                updateBracketAnalysis();
            }} catch (error) {{
                console.error('Error loading week data:', error);
                alert('Failed to load week data: ' + error.message);
                // Reset to current week
                selector.value = 'current';
                changeWeek();
            }} finally {{
                showLoading(false);
            }}
        }}

        // Initialize
        populateWeekSelector();
        updateTable();
        updateBracketAnalysis();
    </script>
</body>
</html>'''

    return html


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({'status': 'ok', 'timestamp': int(time.time())})


@app.route('/api/upload', methods=['POST'])
def upload_data():
    """
    Receive player data from a contributor.
    Expected JSON: { "contributor": "name", "players": [...] }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400

        contributor = data.get('contributor', 'anonymous')
        players = data.get('players', [])

        if not players:
            return jsonify({'error': 'No player data provided'}), 400

        logger.info(f"Received {len(players)} players from contributor: {contributor}")

        # Save raw contributor data for debugging
        contributor_file = os.path.join(CONTRIBUTORS_DIR, f"{contributor}.json")
        with open(contributor_file, 'w') as f:
            json.dump({'timestamp': int(time.time()), 'players': players}, f)

        # Load and merge data
        merged_data = load_merged_data()
        merged_data = merge_player_data(merged_data, players, contributor)
        save_merged_data(merged_data)

        # Regenerate dashboard
        html = generate_dashboard_html(merged_data)
        with open(OUTPUT_FILE, 'w') as f:
            f.write(html)

        logger.info(f"Dashboard regenerated. Total players: {len(merged_data['players'])}")

        return jsonify({
            'status': 'success',
            'players_received': len(players),
            'total_players': len(merged_data['players']),
            'contributors': len(merged_data.get('contributors', {}))
        })

    except Exception as e:
        logger.error(f"Error processing upload: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/players', methods=['GET'])
def get_players():
    """Return the current merged player data."""
    merged_data = load_merged_data()
    players = list(merged_data.get('players', {}).values())
    players.sort(key=lambda x: x.get('thisWeekHonor', 0), reverse=True)

    return jsonify({
        'players': players,
        'total': len(players),
        'last_updated': merged_data.get('last_updated', 0),
        'contributors': merged_data.get('contributors', {})
    })


@app.route('/api/contributors', methods=['GET'])
def get_contributors():
    """Return contributor statistics."""
    merged_data = load_merged_data()
    return jsonify(merged_data.get('contributors', {}))


@app.route('/api/snapshot', methods=['POST'])
def create_snapshot():
    """Take a snapshot of current player data."""
    data = request.get_json() or {}
    label = data.get('label', 'pre_reset')

    snapshot, error = take_snapshot(label)
    if error:
        return jsonify({'error': error}), 400

    return jsonify({
        'status': 'success',
        'filename': f"{label}_{snapshot['date']}.json",
        'player_count': snapshot['player_count'],
        'timestamp': snapshot['timestamp']
    })


@app.route('/api/snapshot', methods=['GET'])
def list_snapshots():
    """List all available snapshots."""
    return jsonify(get_snapshots())


@app.route('/api/snapshot/<filename>', methods=['GET'])
def get_snapshot_data(filename):
    """Get data from a specific snapshot file."""
    # Security: only allow .json files and no path traversal
    if not filename.endswith('.json') or '/' in filename or '\\' in filename:
        return jsonify({'error': 'Invalid filename'}), 400

    filepath = os.path.join(SNAPSHOTS_DIR, filename)
    if not os.path.exists(filepath):
        return jsonify({'error': 'Snapshot not found'}), 404

    try:
        with open(filepath, 'r') as f:
            data = json.load(f)

        # Convert players dict to sorted list
        players = []
        for name, pdata in data.get('players', {}).items():
            player = pdata.copy()
            player['name'] = name
            players.append(player)

        # Sort by thisWeekHonor descending
        players.sort(key=lambda x: x.get('thisWeekHonor', 0), reverse=True)

        return jsonify({
            'label': data.get('label', 'unknown'),
            'date': data.get('date', ''),
            'timestamp': data.get('timestamp', 0),
            'player_count': len(players),
            'players': players
        })
    except Exception as e:
        logger.error(f"Error loading snapshot {filename}: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/week-pairs', methods=['GET'])
def get_week_pairs_api():
    """Get available pre/post reset snapshot pairs."""
    pairs = get_week_pairs()
    return jsonify(pairs)


@app.route('/api/awards', methods=['GET'])
def get_awards():
    """Calculate and return awards comparison."""
    # Check if specific snapshots requested
    pre_snap = request.args.get('pre')
    post_snap = request.args.get('post')

    if pre_snap and post_snap:
        awards_data, error = calculate_awards_from_snapshots(pre_snap, post_snap)
    else:
        awards_data, error = calculate_awards()

    if error:
        return jsonify({'error': error}), 400

    # Also generate and save the HTML page
    html = generate_awards_html(awards_data)
    try:
        with open(AWARDS_OUTPUT_FILE, 'w') as f:
            f.write(html)
        logger.info("Awards HTML page generated")
    except Exception as e:
        logger.error(f"Error saving awards HTML: {e}")

    return jsonify(awards_data)


@app.route('/api/awards/refresh', methods=['POST'])
def refresh_awards():
    """Regenerate the awards HTML page."""
    awards_data, error = calculate_awards()
    if error:
        return jsonify({'error': error}), 400

    html = generate_awards_html(awards_data)
    try:
        with open(AWARDS_OUTPUT_FILE, 'w') as f:
            f.write(html)
        return jsonify({'status': 'success', 'player_count': awards_data['player_count']})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    logger.info("Starting HonorSpy API server on port 5002")
    app.run(host='127.0.0.1', port=5002, debug=False)

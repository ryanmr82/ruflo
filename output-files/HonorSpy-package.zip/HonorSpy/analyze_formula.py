#!/usr/bin/env python3
"""
RP Formula Reverse Engineering Analysis Script
Runs after each snapshot to track edge cases and validate formula hypotheses.
"""

import json
import os
from datetime import datetime

ANALYSIS_DIR = "/home/opc/HonorSpy/analysis"
SNAPSHOTS_DIR = "/home/opc/HonorSpy/snapshots"

# Bracket thresholds
BRACKETS = [
    (14, 0.003, 12000, 13000),
    (13, 0.008, 11000, 12000),
    (12, 0.020, 10000, 11000),
    (11, 0.035, 9000, 10000),
    (10, 0.060, 8000, 9000),
    (9, 0.100, 7000, 8000),
    (8, 0.159, 6000, 7000),
    (7, 0.228, 5000, 6000),
    (6, 0.327, 4000, 5000),
]

def get_bracket_info(standing, pool_size):
    """Get bracket number and boundaries for a standing."""
    prev_cutoff = 0
    for bracket, thresh, rp_min, rp_max in BRACKETS:
        cutoff = int(pool_size * thresh + 0.5)
        if standing <= cutoff:
            return {
                "bracket": bracket,
                "start": prev_cutoff + 1,
                "end": cutoff,
                "spots": cutoff - prev_cutoff,
                "position_in_bracket": standing - prev_cutoff,
                "is_top": standing == prev_cutoff + 1,
                "is_bottom": standing == cutoff,
                "rp_min": rp_min,
                "rp_max": rp_max
            }
        prev_cutoff = cutoff
    return None

def load_awards_data():
    """Load current awards data from API."""
    import urllib.request
    try:
        data = json.load(urllib.request.urlopen("http://localhost:5002/api/awards"))
        return data.get("awards", [])
    except:
        return []

def find_edge_cases(awards, pool_size):
    """Find interesting edge cases for formula validation."""
    results = {
        "timestamp": datetime.now().isoformat(),
        "pool_size": pool_size,
        "total_fresh": 0,
        "bracket_boundaries": [],
        "similar_honor_diff_rp": [],
        "similar_rp_diff_honor": [],
        "bracket_summaries": [],
        "anomalies": []
    }

    # Filter to fresh data only
    fresh = [a for a in awards if a["net_gain"] != 0 and a["award"] > 0]
    results["total_fresh"] = len(fresh)

    # Analyze each bracket
    for bracket, thresh, rp_min, rp_max in BRACKETS[:9]:  # B14 to B6
        cutoff = int(pool_size * thresh + 0.5)
        prev_cutoff = 0
        for b2, t2, _, _ in BRACKETS:
            if b2 == bracket + 1:
                prev_cutoff = int(pool_size * t2 + 0.5)
                break

        bracket_players = [p for p in fresh
                          if p["standing"] > prev_cutoff and p["standing"] <= cutoff]

        if not bracket_players:
            continue

        awards_list = [p["award"] for p in bracket_players]

        summary = {
            "bracket": bracket,
            "standings": f"{prev_cutoff+1}-{cutoff}",
            "spots": cutoff - prev_cutoff,
            "fresh_count": len(bracket_players),
            "official_range": f"{rp_min}-{rp_max}",
            "actual_min": min(awards_list),
            "actual_max": max(awards_list),
            "floor_boost": min(awards_list) - rp_min,
            "ceil_boost": max(awards_list) - rp_max,
            "spread": max(awards_list) - min(awards_list),
            "compression": round((max(awards_list) - min(awards_list)) / 1000 * 100, 1)
        }
        results["bracket_summaries"].append(summary)

        # Find boundary players
        for p in bracket_players:
            info = get_bracket_info(p["standing"], pool_size)
            if info and (info["is_top"] or info["is_bottom"]):
                results["bracket_boundaries"].append({
                    "name": p["name"],
                    "standing": p["standing"],
                    "bracket": bracket,
                    "position": "TOP" if info["is_top"] else "BOTTOM",
                    "honor": p["pre_reset_honor"],
                    "pre_rp": p["pre_reset_rp"],
                    "award": p["award"],
                    "official_expected": rp_max if info["is_top"] else rp_min,
                    "difference": p["award"] - (rp_max if info["is_top"] else rp_min)
                })

    # Find players with similar honor but different Pre-RP (within same bracket)
    for bracket, thresh, rp_min, rp_max in BRACKETS[:6]:
        cutoff = int(pool_size * thresh + 0.5)
        prev_cutoff = 0
        for b2, t2, _, _ in BRACKETS:
            if b2 == bracket + 1:
                prev_cutoff = int(pool_size * t2 + 0.5)
                break

        bracket_players = [p for p in fresh
                          if p["standing"] > prev_cutoff and p["standing"] <= cutoff]

        # Compare pairs
        for i, p1 in enumerate(bracket_players):
            for p2 in bracket_players[i+1:]:
                honor_diff = abs(p1["pre_reset_honor"] - p2["pre_reset_honor"])
                rp_diff = abs(p1["pre_reset_rp"] - p2["pre_reset_rp"])
                award_diff = p1["award"] - p2["award"]

                # Similar honor (within 1%), different Pre-RP (>20% difference)
                avg_honor = (p1["pre_reset_honor"] + p2["pre_reset_honor"]) / 2
                avg_rp = (p1["pre_reset_rp"] + p2["pre_reset_rp"]) / 2

                if avg_honor > 0 and avg_rp > 0:
                    honor_pct_diff = honor_diff / avg_honor * 100
                    rp_pct_diff = rp_diff / avg_rp * 100

                    if honor_pct_diff < 1 and rp_pct_diff > 20:
                        results["similar_honor_diff_rp"].append({
                            "bracket": bracket,
                            "player1": p1["name"],
                            "player2": p2["name"],
                            "honor_diff": honor_diff,
                            "honor_pct_diff": round(honor_pct_diff, 2),
                            "rp_diff": rp_diff,
                            "rp_pct_diff": round(rp_pct_diff, 2),
                            "award_diff": award_diff,
                            "higher_rp_player": p1["name"] if p1["pre_reset_rp"] > p2["pre_reset_rp"] else p2["name"],
                            "higher_rp_got_less": (p1["pre_reset_rp"] > p2["pre_reset_rp"] and p1["award"] < p2["award"]) or
                                                  (p2["pre_reset_rp"] > p1["pre_reset_rp"] and p2["award"] < p1["award"])
                        })

                    # Similar Pre-RP (within 10%), different honor (>5% difference)
                    if rp_pct_diff < 10 and honor_pct_diff > 5:
                        results["similar_rp_diff_honor"].append({
                            "bracket": bracket,
                            "player1": p1["name"],
                            "player2": p2["name"],
                            "honor_diff": honor_diff,
                            "rp_diff": rp_diff,
                            "award_diff": award_diff,
                            "higher_honor_player": p1["name"] if p1["pre_reset_honor"] > p2["pre_reset_honor"] else p2["name"],
                            "higher_honor_got_more": (p1["pre_reset_honor"] > p2["pre_reset_honor"] and p1["award"] > p2["award"]) or
                                                     (p2["pre_reset_honor"] > p1["pre_reset_honor"] and p2["award"] > p1["award"])
                        })

    return results

def compare_weeks(current_analysis, previous_file):
    """Compare current week to previous week."""
    if not os.path.exists(previous_file):
        return None

    with open(previous_file) as f:
        previous = json.load(f)

    comparison = {
        "current_date": current_analysis["timestamp"],
        "previous_date": previous.get("timestamp"),
        "floor_boost_changes": [],
        "formula_consistency": []
    }

    # Compare bracket summaries
    prev_summaries = {s["bracket"]: s for s in previous.get("bracket_summaries", [])}
    for curr in current_analysis.get("bracket_summaries", []):
        prev = prev_summaries.get(curr["bracket"])
        if prev:
            comparison["floor_boost_changes"].append({
                "bracket": curr["bracket"],
                "prev_floor_boost": prev["floor_boost"],
                "curr_floor_boost": curr["floor_boost"],
                "change": curr["floor_boost"] - prev["floor_boost"]
            })

    return comparison

def main():
    print("=" * 60)
    print("RP FORMULA EDGE CASE ANALYSIS")
    print(f"Run time: {datetime.now().isoformat()}")
    print("=" * 60)

    # Ensure analysis directory exists
    os.makedirs(ANALYSIS_DIR, exist_ok=True)

    # Load awards data
    awards = load_awards_data()
    if not awards:
        print("ERROR: Could not load awards data")
        return

    pool_size = 1974  # From pre-reset snapshot

    # Find edge cases
    results = find_edge_cases(awards, pool_size)

    # Save results
    output_file = os.path.join(ANALYSIS_DIR, f"edge_cases_{datetime.now().strftime('%Y-%m-%d_%H-%M')}.json")
    with open(output_file, "w") as f:
        json.dump(results, f, indent=2)

    # Print summary
    print(f"\nTotal fresh players: {results['total_fresh']}")

    print("\n=== BRACKET SUMMARIES ===")
    for s in results["bracket_summaries"]:
        print(f"B{s['bracket']:2}: {s['actual_min']}-{s['actual_max']} (floor +{s['floor_boost']}, ceil {s['ceil_boost']:+d}, {s['compression']}% spread)")

    print("\n=== BRACKET BOUNDARY PLAYERS ===")
    for p in results["bracket_boundaries"]:
        print(f"B{p['bracket']} {p['position']:6}: {p['name']:15} Award:{p['award']:5} (expected {p['official_expected']}, diff {p['difference']:+d})")

    print("\n=== SIMILAR HONOR, DIFFERENT PRE-RP (Key for formula) ===")
    for p in results["similar_honor_diff_rp"]:
        catch_up = "YES" if p["higher_rp_got_less"] else "NO"
        print(f"B{p['bracket']}: {p['player1']} vs {p['player2']} | Honor diff: {p['honor_pct_diff']}% | RP diff: {p['rp_pct_diff']}% | Award diff: {p['award_diff']:+d} | Catch-up effect: {catch_up}")

    if not results["similar_honor_diff_rp"]:
        print("(No pairs found - need more players with similar honor)")

    print("\n=== SIMILAR PRE-RP, DIFFERENT HONOR ===")
    for p in results["similar_rp_diff_honor"]:
        honor_wins = "YES" if p["higher_honor_got_more"] else "NO"
        print(f"B{p['bracket']}: {p['player1']} vs {p['player2']} | Award diff: {p['award_diff']:+d} | Higher honor got more: {honor_wins}")

    if not results["similar_rp_diff_honor"]:
        print("(No pairs found - need more players with similar Pre-RP)")

    # Compare to previous week if available
    prev_files = sorted([f for f in os.listdir(ANALYSIS_DIR) if f.startswith("edge_cases_")])
    if len(prev_files) > 1:
        prev_file = os.path.join(ANALYSIS_DIR, prev_files[-2])
        comparison = compare_weeks(results, prev_file)
        if comparison:
            print("\n=== WEEK-OVER-WEEK COMPARISON ===")
            for c in comparison.get("floor_boost_changes", []):
                if c["change"] != 0:
                    print(f"B{c['bracket']}: Floor boost changed from {c['prev_floor_boost']} to {c['curr_floor_boost']} ({c['change']:+d})")

    print(f"\nResults saved to: {output_file}")
    print("=" * 60)

if __name__ == "__main__":
    main()

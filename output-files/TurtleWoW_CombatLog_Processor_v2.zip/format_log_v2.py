#!/usr/bin/python3

import os
import re
import shutil
import time
import zipfile
import json
from datetime import datetime, timedelta
from collections import defaultdict

# Load the original formatting functions
def handle_replacements(line, replacements):
    for pattern, replacement in replacements.items():
        try:
            new_text, num_subs = re.subn(pattern, replacement, line, flags=re.IGNORECASE)
        except Exception as e:
            print(f"Error replacing pattern: {pattern} with replacement: {replacement}")
            print(f"Line: {line}")
            raise e
        if num_subs:
            return new_text
    return line


def parse_log_timestamp(line):
    """Extract timestamp from log line. Format: M/D HH:MM:SS.mmm"""
    match = re.match(r'^(\d{1,2})/(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})\.\d{3}', line)
    if match:
        month, day, hour, minute, second = map(int, match.groups())
        # Assume current year
        year = datetime.now().year
        try:
            return datetime(year, month, day, hour, minute, second)
        except ValueError:
            return None
    return None


def parse_user_datetime(date_str, time_str):
    """Parse user-friendly datetime: '10/20/2025' '4:00 PM'"""
    try:
        combined = f"{date_str} {time_str}"
        # Try multiple formats
        for fmt in ['%m/%d/%Y %I:%M %p', '%m/%d/%Y %H:%M', '%Y-%m-%d %I:%M %p', '%Y-%m-%d %H:%M']:
            try:
                return datetime.strptime(combined, fmt)
            except ValueError:
                continue
        print(f"Could not parse datetime: {combined}")
        return None
    except Exception as e:
        print(f"Error parsing datetime: {e}")
        return None


def detect_boss_death(lines, boss_name, start_time):
    """Detect when a boss dies in the log after start_time"""
    if not boss_name:
        return None

    pattern = rf"{boss_name} dies\."
    print(f"Searching for boss death: '{pattern}' after {start_time.strftime('%I:%M %p')}")

    for line in lines:
        timestamp = parse_log_timestamp(line)
        if timestamp and timestamp >= start_time:
            if re.search(pattern, line, re.IGNORECASE):
                print(f"✅ Found: {boss_name} dies at {timestamp.strftime('%I:%M:%S %p')}")
                return timestamp

    print(f"⚠️  No boss death found for {boss_name}")
    return None


def detect_raid_exodus(lines, start_time, exodus_patterns, threshold=3, window_minutes=3):
    """Detect when multiple people start leaving (hearthing/portaling)"""
    print(f"Searching for raid exodus ({threshold}+ people leaving within {window_minutes} min)...")

    # Track who left and when
    exodus_events = []

    for line in lines:
        timestamp = parse_log_timestamp(line)
        if not timestamp or timestamp < start_time:
            continue

        # Check for exodus patterns
        for pattern_name, pattern in exodus_patterns.items():
            if pattern in line:
                # Extract player name
                match = re.match(r'^\d{1,2}/\d{1,2}\s+\d{2}:\d{2}:\d{2}\.\d{3}\s+([A-Za-z]+)\s+begins to cast', line)
                if match:
                    player_name = match.group(1)
                    exodus_events.append({
                        'timestamp': timestamp,
                        'player': player_name,
                        'action': pattern_name
                    })

    # Look for clusters of exodus events
    if len(exodus_events) < threshold:
        print(f"⚠️  Only {len(exodus_events)} exodus events found (need {threshold}+)")
        return None

    # Sort by timestamp
    exodus_events.sort(key=lambda x: x['timestamp'])

    # Find first cluster of threshold+ events within window
    for i in range(len(exodus_events) - threshold + 1):
        first_event = exodus_events[i]
        events_in_window = [first_event]

        for j in range(i + 1, len(exodus_events)):
            event = exodus_events[j]
            time_diff = (event['timestamp'] - first_event['timestamp']).total_seconds() / 60

            if time_diff <= window_minutes:
                events_in_window.append(event)
            else:
                break

        if len(events_in_window) >= threshold:
            print(f"✅ Found exodus: {len(events_in_window)} people left between {first_event['timestamp'].strftime('%I:%M %p')} - {events_in_window[-1]['timestamp'].strftime('%I:%M %p')}")
            for event in events_in_window[:5]:  # Show first 5
                print(f"   - {event['player']} at {event['timestamp'].strftime('%I:%M:%S %p')}")
            return first_event['timestamp']

    print(f"⚠️  No clear exodus pattern detected")
    return None


def extract_time_range(input_file, output_file, start_time, end_time):
    """Extract only log lines within the specified time range"""
    print(f"\nExtracting combat log from {start_time.strftime('%m/%d/%Y %I:%M %p')} to {end_time.strftime('%m/%d/%Y %I:%M %p')}...")

    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    extracted_lines = []
    lines_extracted = 0

    for line in lines:
        timestamp = parse_log_timestamp(line)
        if timestamp and start_time <= timestamp <= end_time:
            extracted_lines.append(line)
            lines_extracted += 1

    # Write extracted lines to output file
    with open(output_file, 'w', encoding='utf-8') as f:
        f.writelines(extracted_lines)

    duration = end_time - start_time
    hours = duration.total_seconds() / 3600
    print(f"✅ Extracted {lines_extracted:,} lines covering {hours:.2f} hours")

    return output_file


def archive_original_log(filename):
    """Archive the original log file with timestamp"""
    timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")

    # Archive both WoWCombatLog.txt and WoWRawCombatLog.txt
    logs_to_archive = [
        ('WoWCombatLog.txt', f"WoWCombatLog.archived.{timestamp}.txt"),
        ('WoWRawCombatLog.txt', f"WoWRawCombatLog.archived.{timestamp}.txt")
    ]

    archived_files = []

    for original, archive_name in logs_to_archive:
        if os.path.exists(original):
            print(f"Archiving {original} as: {archive_name}")
            shutil.copyfile(original, archive_name)

            # Clear the original file for new combat logging
            open(original, 'w').close()
            print(f"✅ {original} archived and cleared")
            archived_files.append(archive_name)
        else:
            print(f"⚠️  {original} not found, skipping")

    print(f"✅ All combat logs archived and cleared for new raids")
    return archived_files


def replace_instances(player_name, filename):
    """Original formatting function from format_log_for_upload.py"""
    player_name = player_name.strip().capitalize()

    # All the original replacement logic from the old script
    L = "a-zA-Z\\u00C0-\\u017F"

    mob_names_with_apostrophe = {
        "Onyxia's Elite Guard": "Onyxias Elite Guard",
        "Sartura's Royal Guard": "Sarturas Royal Guard",
        "Medivh's Merlot Blue Label": "Medivhs Merlot Blue Label",
        "Ima'ghaol, Herald of Desolation": "Imaghaol, Herald of Desolation",
    }

    pet_rename_replacements = {}

    pet_replacements = {
        rf"  ([{L}][{L} ]+[{L}]) \(([{L}]+)\) (hits|crits|misses)": r"  \g<2>'s Auto Attack (pet) \g<3>",
        rf"  Your ([{L}][{L} ]+[{L}]) \(([{L}]+)\) is dismissed.": r"  \g<2>'s \g<1> (\g<2>) is dismissed.",
        rf"  ([{L}][{L} ]+[{L}]) \(([{L}]+)\)('s| 's) Arcane Missiles": r"  \g<2> 's Arcane Missiles (pet)",
        rf"  ([{L}][{L} ]+[{L}]) \(([{L}]+)\)('s| 's)": r"  \g<2> 's",
        rf"from ([{L}][{L} ]+[{L}]) \(([{L}]+)\)('s| 's)": r"from \g<2>\g<3>",
    }

    you_replacements = {
        r'.*You fail to cast.*\n': '',
        r'.*You fail to perform.*\n': '',
        r" You suffer (.*?) from your": rf" {player_name} suffers \g<1> from {player_name} (self damage) 's",
        r" Your (.*?) hits you for": rf" {player_name} (self damage) 's \g<1> hits {player_name} for",
        r" Your (.*?) is parried by": rf" {player_name} 's \g<1> was parried by",
        r" Your (.*?) failed": rf" {player_name} 's \g<1> fails",
        r" failed\. You are immune": rf" fails. {player_name} is immune",
        r" [Yy]our ": f" {player_name} 's ",
        r" You gain (.*?) from (.*?)'s": rf" {player_name} gains \g<1> from \g<2> 's",
        r" You gain (.*?) from ": rf" {player_name} gains \g<1> from {player_name} 's ",
        " You gain": f" {player_name} gains",
        " You hit": f" {player_name} hits",
        " You crit": f" {player_name} crits",
        " You are": f" {player_name} is",
        " You suffer": f" {player_name} suffers",
        " You lose": f" {player_name} loses",
        " You die": f" {player_name} dies",
        " You cast": f" {player_name} casts",
        " You create": f" {player_name} creates",
        " You perform": f" {player_name} performs",
        " You interrupt": f" {player_name} interrupts",
        " You miss": f" {player_name} misses",
        " You attack": f" {player_name} attacks",
        " You block": f" {player_name} blocks",
        " You parry": f" {player_name} parries",
        " You dodge": f" {player_name} dodges",
        " You resist": f" {player_name} resists",
        " You absorb": f" {player_name} absorbs",
        " You reflect": f" {player_name} reflects",
        " You receive": f" {player_name} receives",
        "&You receive": f"&{player_name} receives",
        " You deflect": f" {player_name} deflects",
        r"was dodged\.": f"was dodged by {player_name}.",
        "causes you": f"causes {player_name}",
        "heals you": f"heals {player_name}",
        "hits you for": f"hits {player_name} for",
        "crits you for": f"crits {player_name} for",
        r" You have slain (.*?)!": rf" \g<1> is slain by {player_name}.",
        r"(\S)\syou\.": rf"\g<1> {player_name}.",
        " You fall and lose": f" {player_name} falls and loses",
    }

    generic_replacements = {
        r" fades from .*\.": r"\g<0>",
        r" gains .*\)\.": r"\g<0>",
        r" is afflicted by .*\)\.": r"\g<0>",
        rf"  ([{L}'\- ]*?\S)'s ([A-Z])": r"  \g<1> 's \g<2>",
        rf"from ([{L}'\- ]*?\S)'s ([A-Z])": r"from \g<1> 's \g<2>",
        rf"is immune to ([{L}'\- ]*?\S)'s ([A-Z])": r"is immune to \g<1> 's \g<2>",
        r"\)'s ([A-Z])": r") 's \g<1>",
    }

    renames = {
        rf"  [A-Z][{L} ]* Totem [IVX]+ \((.*?)\) 's": r"  \g<1> 's",
        rf" from [A-Z][{L} ]* Totem [IVX]+ \((.*?)\) 's": r" from \g<1> 's",
        r"Lightning Strike was resisted": r"Lightning Strike (nature) was resisted",
        r"Lightning Strike (.*) Nature damage": r"Lightning Strike (nature) \g<1> Nature damage",
        "Onyxias Elite Guard": "Onyxia's Elite Guard",
        "Sarturas Royal Guard": "Sartura's Royal Guard",
    }

    friendly_fire = {
        rf"from ([{L}]*?) 's Power Overwhelming": r"from \g<1> (self damage) 's Power Overwhelming",
    }

    self_damage = {
        rf"  ([{L}' ]*?) suffers (.*) (damage) from ([{L}' ]*?) 's": r"  \g<1> suffers \g<2> damage from \g<4> (self damage) 's",
        rf"  ([{L}' ]*?) 's (.*) (hits|crits) ([{L}' ]*?) for": r"  \g<1> (self damage) 's \g<2> \g<3> \g<4> for",
    }

    loot_replacements = {
        r"\|h\|r\.$": "|h|rx1.",
    }

    # Create backup
    backup_filename = filename.replace(".txt", "") + f".original.{int(time.time())}.txt"
    shutil.copyfile(filename, backup_filename)

    # Read the file
    with open(filename, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    # Process pet names
    pet_renames = set()
    pet_names = set()
    owner_names = set()
    ignored_pet_names = {"Razorgore the Untamed (", "Deathknight Understudy (", "Naxxramas Worshipper ("}
    summoned_pet_names = {"Greater Feral Spirit", "Battle Chicken", "Arcanite Dragonling", "The Lost", "Minor Arcane Elemental", "Scytheclaw Pureborn", "Explosive Trap I", "Explosive Trap II", "Explosive Trap III"}
    summoned_pet_owner_regex = rf"([{L}][{L} ]+[{L}]) \(([{L}]+)\)"

    for i, _ in enumerate(lines):
        lines[i] = lines[i].replace(" 's", "'s")
        if "COMBATANT_INFO" in lines[i]:
            try:
                line_parts = lines[i].split("&")
                pet_name = line_parts[5]
                if pet_name != "nil" and pet_name not in ignored_pet_names:
                    owner_name = line_parts[1]
                    if pet_name == owner_name:
                        pet_renames.add(pet_name)
                        pet_rename_replacements[rf"{pet_name} \({owner_name}\)"] = f"{pet_name}Pet ({owner_name})"
                        line_parts[5] = f"{pet_name}Pet"
                    pet_names.add(f"{pet_name}")
                    owner_names.add(f"({line_parts[1]})")
                else:
                    line_parts[5] = "nil"
                lines[i] = "&".join(line_parts)
            except Exception as e:
                print(f"Error parsing pet name from line: {lines[i]}")
                print(e)
        elif "LOOT:" in lines[i]:
            lines[i] = handle_replacements(lines[i], loot_replacements)
        else:
            for summoned_pet_name in summoned_pet_names:
                if summoned_pet_name in lines[i]:
                    match = re.search(summoned_pet_owner_regex, lines[i])
                    if match:
                        pet_names.add(summoned_pet_name)
                        owner_names.add(f"({match.group(2)})")

    # Perform all replacements
    for i, _ in enumerate(lines):
        lines[i] = handle_replacements(lines[i], mob_names_with_apostrophe)
        if pet_rename_replacements:
            lines[i] = handle_replacements(lines[i], pet_rename_replacements)
        for owner_name in owner_names:
            if owner_name in lines[i]:
                if "dies." in lines[i] or "is killed by" in lines[i]:
                    continue
                if not any(ignored_pet_name in lines[i] for ignored_pet_name in ignored_pet_names):
                    lines[i] = handle_replacements(lines[i], pet_replacements)
        if "you" in lines[i] or "You" in lines[i] or "dodged." in lines[i]:
            lines[i] = handle_replacements(lines[i], you_replacements)
            lines[i] = handle_replacements(lines[i], you_replacements)
        lines[i] = handle_replacements(lines[i], generic_replacements)
        lines[i] = handle_replacements(lines[i], renames)
        for pattern, replacement in friendly_fire.items():
            match = re.search(pattern, lines[i])
            if match:
                lines[i] = handle_replacements(lines[i], {pattern: replacement})
                break
        for pattern, replacement in self_damage.items():
            match = re.search(pattern, lines[i])
            if match and match.group(1).strip() == match.group(4).strip():
                lines[i] = handle_replacements(lines[i], {pattern: replacement})
                break

    # Write back
    with open(filename, 'w', encoding='utf-8') as file:
        file.writelines(lines)


def create_zip_file(source_file, zip_filename):
    """Create zip file for upload"""
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(source_file, arcname=os.path.basename(source_file))
    print(f"✅ Created ZIP: {zip_filename}")


def main_cli():
    """Command-line interface version"""
    print("=" * 60)
    print("Turtle WoW Combat Log Processor v2.0")
    print("=" * 60)
    print()

    # Load raids configuration
    try:
        with open('raids.json', 'r') as f:
            config = json.load(f)
            raids_config = config['raids']
            exodus_patterns = config['exodus_patterns']
            settings = config['settings']
    except Exception as e:
        print(f"Error loading raids.json: {e}")
        return

    # Get user inputs
    player_name = input("Enter player name: ")

    print("\nAvailable raids:")
    for key, raid in raids_config.items():
        print(f"  {key}: {raid['name']}")

    raid_key = input("\nEnter raid (e.g., MC, BWL, AQ40): ").upper().strip()

    if raid_key not in raids_config:
        print(f"Unknown raid: {raid_key}")
        return

    raid_info = raids_config[raid_key]
    print(f"\nSelected: {raid_info['full_name']}")

    # Get start time
    start_date = input("Enter start date (MM/DD/YYYY): ")
    start_time_str = input("Enter start time (e.g., 4:00 PM): ")
    start_time = parse_user_datetime(start_date, start_time_str)

    if not start_time:
        print("Invalid start time format")
        return

    # Load log file
    filename = input("Enter filename (default: WoWCombatLog.txt): ").strip()
    if not filename:
        filename = 'WoWCombatLog.txt'

    if not os.path.exists(filename):
        print(f"File not found: {filename}")
        return

    print(f"\nReading {filename}...")
    with open(filename, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    print(f"Loaded {len(lines):,} lines")

    # Detect end time
    end_time = None
    end_method = "manual"

    # Try boss death detection
    if raid_info['final_boss']:
        boss_death_time = detect_boss_death(lines, raid_info['final_boss'], start_time)
        if boss_death_time:
            end_time = boss_death_time
            end_method = "boss_death"

    # Try exodus detection if no boss death
    if not end_time:
        exodus_time = detect_raid_exodus(
            lines,
            start_time,
            exodus_patterns,
            settings['exodus_threshold'],
            settings['exodus_time_window_minutes']
        )
        if exodus_time:
            end_time = exodus_time
            end_method = "exodus"

    # Manual entry if needed
    if not end_time:
        print("\n⚠️  Could not auto-detect end time")
        end_date = input("Enter end date (MM/DD/YYYY): ")
        end_time_str = input("Enter end time (e.g., 6:30 PM): ")
        end_time = parse_user_datetime(end_date, end_time_str)

        if not end_time:
            print("Invalid end time format")
            return

    # Create output filename
    timestamp = start_time.strftime("%Y-%m-%d")
    boss_suffix = raid_info['final_boss'] if end_method == "boss_death" else "NoKill"
    output_filename = f"TurtLog-{raid_key}-{timestamp}-{boss_suffix}.txt"

    # Extract time range
    temp_extracted = "temp_extracted.txt"
    extract_time_range(filename, temp_extracted, start_time, end_time)

    # Format the extracted log
    replace_instances(player_name, temp_extracted)

    # Rename to final output
    os.rename(temp_extracted, output_filename)
    print(f"✅ Created formatted log: {output_filename}")

    # Create ZIP
    if settings.get('create_zip', True):
        create_zip_file(output_filename, output_filename + ".zip")

    # Archive original
    if settings.get('archive_original_log', True):
        archive_original_log(filename)

    print("\n" + "=" * 60)
    print("✅ Processing Complete!")
    print("=" * 60)
    print(f"Output: {output_filename}")
    print(f"ZIP: {output_filename}.zip")
    print(f"Detection method: {end_method}")
    print("=" * 60)


if __name__ == "__main__":
    main_cli()

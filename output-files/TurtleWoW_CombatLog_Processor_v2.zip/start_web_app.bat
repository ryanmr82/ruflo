@echo off
cd /d %~dp0

echo.
echo ========================================
echo  Turtle WoW Combat Log Processor
echo  Web Interface Starting...
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.x from python.org
    pause
    exit /b 1
)

REM Check if Flask is installed, install if not
python -c "import flask" 2>nul
if errorlevel 1 (
    echo Flask not found. Installing Flask...
    pip install -r requirements.txt
)

echo.
echo Starting web server...
echo.
echo Your browser should open automatically to:
echo   http://localhost:5000
echo.
echo If it doesn't, copy and paste that URL into your browser.
echo.
echo Press Ctrl+C to stop the server when done.
echo.

REM Wait a moment then open browser
timeout /t 2 /nobreak >nul
start http://localhost:5000

REM Start Flask app
python flask_app.py

pause

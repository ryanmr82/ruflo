#!/usr/bin/python3

from flask import Flask, render_template_string, request, jsonify, send_file
import os
import json
from datetime import datetime
from format_log_v2 import (
    parse_log_timestamp, parse_user_datetime, detect_boss_death,
    detect_raid_exodus, extract_time_range, replace_instances,
    create_zip_file, archive_original_log
)

app = Flask(__name__)

# HTML Template
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Turtle WoW Combat Log Processor</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
        }
        h1 {
            color: #667eea;
            text-align: center;
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 25px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        input[type="text"]:focus, select:focus {
            outline: none;
            border-color: #667eea;
        }
        .time-inputs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .radio-group {
            display: flex;
            gap: 20px;
            margin-top: 10px;
        }
        .radio-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: normal;
            cursor: pointer;
        }
        button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        button:hover {
            transform: translateY(-2px);
        }
        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        .status-box {
            margin-top: 30px;
            padding: 20px;
            background: #f5f5f5;
            border-radius: 8px;
            display: none;
        }
        .status-box.show {
            display: block;
        }
        .status-line {
            padding: 8px 0;
            font-size: 14px;
        }
        .status-line.success { color: #10b981; }
        .status-line.warning { color: #f59e0b; }
        .status-line.error { color: #ef4444; }
        .status-line.info { color: #3b82f6; }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e0e0e0;
            border-radius: 4px;
            overflow: hidden;
            margin: 15px 0;
            display: none;
        }
        .progress-bar.show {
            display: block;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            width: 0%;
            transition: width 0.3s;
        }
        .download-button {
            margin-top: 15px;
            background: #10b981;
            display: none;
        }
        .download-button.show {
            display: block;
        }
        .help-text {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .icon { margin-right: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🐢 Turtle WoW Combat Log Processor</h1>
        <p class="subtitle">Extract and format raid logs for Legacy Logs upload</p>

        <form id="logForm">
            <div class="form-group">
                <label for="playerName">Player Name</label>
                <input type="text" id="playerName" name="playerName" required placeholder="Your character name">
            </div>

            <div class="form-group">
                <label for="raid">Raid</label>
                <select id="raid" name="raid" required>
                    <option value="">Select a raid...</option>
                </select>
                <p class="help-text">Select which raid you participated in</p>
            </div>

            <div class="form-group">
                <label>Start Time</label>
                <div class="time-inputs">
                    <input type="text" id="startDate" name="startDate" required placeholder="MM/DD/YYYY">
                    <input type="text" id="startTime" name="startTime" required placeholder="4:00 PM">
                </div>
                <p class="help-text">When did the raid start?</p>
            </div>

            <div class="form-group">
                <label>End Time Detection</label>
                <div class="radio-group">
                    <label>
                        <input type="radio" name="endMode" value="auto" checked>
                        <span>Auto-detect (boss death + exodus)</span>
                    </label>
                    <label>
                        <input type="radio" name="endMode" value="manual">
                        <span>Manual entry</span>
                    </label>
                </div>
            </div>

            <div class="form-group" id="manualEndGroup" style="display:none;">
                <label>Manual End Time</label>
                <div class="time-inputs">
                    <input type="text" id="endDate" name="endDate" placeholder="MM/DD/YYYY">
                    <input type="text" id="endTime" name="endTime" placeholder="6:30 PM">
                </div>
            </div>

            <button type="submit" id="submitBtn">
                <span class="icon">🚀</span> Process Combat Log
            </button>
        </form>

        <div class="progress-bar" id="progressBar">
            <div class="progress-fill" id="progressFill"></div>
        </div>

        <div class="status-box" id="statusBox"></div>

        <button class="download-button" id="downloadBtn" onclick="downloadFile()">
            <span class="icon">📥</span> Download ZIP File
        </button>
    </div>

    <script>
        let outputFilename = '';

        // Load raids from config
        fetch('/api/raids')
            .then(r => r.json())
            .then(data => {
                const select = document.getElementById('raid');
                Object.entries(data.raids).forEach(([key, raid]) => {
                    if (key !== 'CUSTOM') {
                        const option = document.createElement('option');
                        option.value = key;
                        option.textContent = `${key} - ${raid.name}`;
                        select.appendChild(option);
                    }
                });
            });

        // Toggle manual end time
        document.querySelectorAll('input[name="endMode"]').forEach(radio => {
            radio.addEventListener('change', (e) => {
                document.getElementById('manualEndGroup').style.display =
                    e.target.value === 'manual' ? 'block' : 'none';
            });
        });

        // Form submission
        document.getElementById('logForm').addEventListener('submit', async (e) => {
            e.preventDefault();

            const submitBtn = document.getElementById('submitBtn');
            const statusBox = document.getElementById('statusBox');
            const progressBar = document.getElementById('progressBar');
            const progressFill = document.getElementById('progressFill');
            const downloadBtn = document.getElementById('downloadBtn');

            submitBtn.disabled = true;
            statusBox.innerHTML = '';
            statusBox.classList.add('show');
            progressBar.classList.add('show');
            downloadBtn.classList.remove('show');
            progressFill.style.width = '0%';

            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);

            addStatus('info', '🔍 Processing combat log...');
            progressFill.style.width = '10%';

            try {
                const response = await fetch('/api/process', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                const result = await response.json();
                progressFill.style.width = '100%';

                if (result.success) {
                    addStatus('success', '✅ ' + result.message);
                    if (result.boss_death) {
                        addStatus('success', `✅ Found: ${result.boss_name} dies at ${result.boss_death}`);
                    }
                    if (result.exodus) {
                        addStatus('success', `✅ Found exodus: ${result.exodus_count} people left around ${result.exodus_time}`);
                    }
                    if (result.method === 'manual') {
                        addStatus('info', '📝 Used manual end time');
                    }
                    addStatus('success', `✅ Extracted ${result.lines} lines covering ${result.duration}`);
                    addStatus('success', `✅ Created: ${result.output}`);

                    outputFilename = result.output + '.zip';
                    downloadBtn.classList.add('show');
                } else {
                    addStatus('error', '❌ Error: ' + result.error);
                }
            } catch (error) {
                addStatus('error', '❌ Error: ' + error.message);
                progressFill.style.width = '0%';
            }

            submitBtn.disabled = false;
        });

        function addStatus(type, message) {
            const statusBox = document.getElementById('statusBox');
            const line = document.createElement('div');
            line.className = `status-line ${type}`;
            line.textContent = message;
            statusBox.appendChild(line);
        }

        function downloadFile() {
            window.location.href = `/download/${outputFilename}`;
        }

        // Auto-fill today's date
        const today = new Date();
        const dateStr = `${today.getMonth()+1}/${today.getDate()}/${today.getFullYear()}`;
        document.getElementById('startDate').value = dateStr;
    </script>
</body>
</html>
'''


@app.route('/')
def index():
    """Serve the main page"""
    return render_template_string(HTML_TEMPLATE)


@app.route('/api/raids')
def get_raids():
    """Return raids configuration"""
    try:
        with open('raids.json', 'r') as f:
            config = json.load(f)
        return jsonify(config)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/process', methods=['POST'])
def process_log():
    """Process the combat log"""
    try:
        data = request.json

        # Load config
        with open('raids.json', 'r') as f:
            config = json.load(f)
            raids_config = config['raids']
            exodus_patterns = config['exodus_patterns']
            settings = config['settings']

        # Parse inputs
        player_name = data['playerName']
        raid_key = data['raid']
        start_date = data['startDate']
        start_time_str = data['startTime']
        end_mode = data['endMode']

        raid_info = raids_config[raid_key]
        start_time = parse_user_datetime(start_date, start_time_str)

        if not start_time:
            return jsonify({'success': False, 'error': 'Invalid start time format'}), 400

        # Load log file
        filename = 'WoWCombatLog.txt'
        if not os.path.exists(filename):
            return jsonify({'success': False, 'error': 'WoWCombatLog.txt not found'}), 404

        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # Detect end time
        end_time = None
        end_method = "manual"
        boss_death_str = None
        exodus_data = None

        if end_mode == 'auto':
            # Try boss death
            if raid_info['final_boss']:
                boss_death_time = detect_boss_death(lines, raid_info['final_boss'], start_time)
                if boss_death_time:
                    end_time = boss_death_time
                    end_method = "boss_death"
                    boss_death_str = boss_death_time.strftime('%I:%M:%S %p')

            # Try exodus if no boss
            if not end_time:
                exodus_time = detect_raid_exodus(
                    lines, start_time, exodus_patterns,
                    settings['exodus_threshold'],
                    settings['exodus_time_window_minutes']
                )
                if exodus_time:
                    end_time = exodus_time
                    end_method = "exodus"
                    exodus_data = {
                        'time': exodus_time.strftime('%I:%M %p'),
                        'count': settings['exodus_threshold']
                    }

        # Manual end time
        if not end_time or end_mode == 'manual':
            end_date = data.get('endDate')
            end_time_str = data.get('endTime')
            if not end_date or not end_time_str:
                return jsonify({'success': False, 'error': 'End time required (could not auto-detect)'}), 400

            end_time = parse_user_datetime(end_date, end_time_str)
            if not end_time:
                return jsonify({'success': False, 'error': 'Invalid end time format'}), 400
            end_method = "manual"

        # Create output filename
        timestamp = start_time.strftime("%Y-%m-%d")
        boss_suffix = raid_info['final_boss'] if end_method == "boss_death" else "NoKill"
        output_filename = f"TurtLog-{raid_key}-{timestamp}-{boss_suffix}.txt"

        # Extract time range
        temp_extracted = "temp_extracted.txt"
        extract_time_range(filename, temp_extracted, start_time, end_time)

        # Format
        replace_instances(player_name, temp_extracted)

        # Rename
        if os.path.exists(output_filename):
            os.remove(output_filename)
        os.rename(temp_extracted, output_filename)

        # Create ZIP
        if settings.get('create_zip', True):
            zip_filename = output_filename + ".zip"
            if os.path.exists(zip_filename):
                os.remove(zip_filename)
            create_zip_file(output_filename, zip_filename)

        # Archive original
        if settings.get('archive_original_log', True):
            archive_original_log(filename)

        # Calculate duration
        duration = end_time - start_time
        hours = duration.total_seconds() / 3600

        # Count lines
        with open(output_filename, 'r', encoding='utf-8') as f:
            line_count = len(f.readlines())

        result = {
            'success': True,
            'message': 'Combat log processed successfully!',
            'output': output_filename,
            'method': end_method,
            'lines': f"{line_count:,}",
            'duration': f"{hours:.2f} hours",
            'boss_death': boss_death_str,
            'boss_name': raid_info['final_boss'],
            'exodus': exodus_data is not None,
            'exodus_time': exodus_data['time'] if exodus_data else None,
            'exodus_count': exodus_data['count'] if exodus_data else None
        }

        return jsonify(result)

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/download/<filename>')
def download(filename):
    """Download the processed file"""
    try:
        return send_file(filename, as_attachment=True)
    except Exception as e:
        return jsonify({'error': str(e)}), 404


if __name__ == '__main__':
    print("=" * 60)
    print("🐢 Turtle WoW Combat Log Processor - Web Interface")
    print("=" * 60)
    print()
    print("Starting web server...")
    print("Open your browser to: http://localhost:5000")
    print()
    print("Press Ctrl+C to stop the server")
    print("=" * 60)
    app.run(debug=True, host='127.0.0.1', port=5000)
